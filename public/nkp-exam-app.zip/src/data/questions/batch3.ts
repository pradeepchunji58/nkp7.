import { Question } from '../../types';

export const batch3Questions: Question[] = [
  {
    id: 'nkp-q41',
    badge: 'Kommander Multi-Cluster Projects',
    title: 'Configuring Cluster Placement in Project Creation',
    scenario:
      'An administrator creates a project with the following requirements: Two clusters, CPU Limit 12, Memory Limit 24Gi. The admin runs the following command:\nnkp create project project1 --clusters cluster1,cluster2 --cpu-limit 12 --memory-limit 24Gi\nThe command fails because the --clusters flag does not take a comma-separated list of names directly.',
    prompt: 'What should the admin do to create the project according to the requirements?',
    options: [
      {
        id: 'a',
        text: 'Use the --cluster-selector flag with a label selector matching the target clusters.',
        isCorrect: true,
        explanation: 'Correct! In Kommander, Projects map to clusters using cluster selectors (labels). To target cluster1 and cluster2, specify `--cluster-selector` matching the cluster labels or project placement criteria.',
        nutanixEquivalent: 'Cluster Placement via --cluster-selector',
      },
      {
        id: 'b',
        text: 'Run the command once for each cluster without specifying resource limits.',
        isCorrect: false,
        explanation: 'Resource limits are mandatory for this requirement, and running it twice creates naming collisions.',
        nutanixEquivalent: 'Duplicate Project Creation',
      },
      {
        id: 'c',
        text: 'Create separate projects on each individual cluster bypassing Kommander.',
        isCorrect: false,
        explanation: 'Bypassing Kommander violates centralized governance and multi-cluster project management.',
        nutanixEquivalent: 'Unmanaged Local Projects',
      },
      {
        id: 'd',
        text: 'Set the limits in Prism Central instead of NKP.',
        isCorrect: false,
        explanation: 'Prism Central governs AHV infrastructure, not Kubernetes namespace resource quotas.',
        nutanixEquivalent: 'Prism Central VM Limits',
      },
    ],
    correctOptionId: 'a',
    keyTakeaway: 'In Kommander, projects bind to target clusters using cluster label selectors (`--cluster-selector`), allowing dynamic and multi-cluster placement.',
    deepExplanation: `Kommander Multi-Cluster Projects:
- A Project defines a logical grouping of namespaces across member clusters.
- Instead of static cluster lists, Kommander uses Kubernetes label selectors:
  \`--cluster-selector 'kommander.nutanix.com/cluster-name in (cluster1, cluster2)'\`
- Resource quotas (CPU, memory) defined on the project are enforced across the resulting namespaces on all matched clusters.`,
  },
  {
    id: 'nkp-q42',
    badge: 'Security Policies & Governance',
    title: 'Deploying Gatekeeper for Kubernetes Policy Enforcement',
    scenario:
      'A security engineer is performing security scanning on an NKP cluster that has recently been deployed. The organization requires automated admission control to block privileged containers and enforce compliant image registries.',
    prompt: 'Which tool should the security engineer deploy to the NKP cluster to meet this requirement?',
    options: [
      {
        id: 'a',
        text: 'Velero',
        isCorrect: false,
        explanation: 'Velero handles disaster recovery, backup, and restore of cluster state, not admission policy enforcement.',
        nutanixEquivalent: 'Velero Backup',
      },
      {
        id: 'b',
        text: 'Gatekeeper (Open Policy Agent)',
        isCorrect: true,
        explanation: 'Correct! Gatekeeper is an Open Policy Agent (OPA) admission controller available as an NKP platform application that audits and blocks non-compliant Kubernetes API requests.',
        nutanixEquivalent: 'OPA Gatekeeper Platform Application',
      },
      {
        id: 'c',
        text: 'MetalLB',
        isCorrect: false,
        explanation: 'MetalLB provides bare-metal layer-2 network load balancing.',
        nutanixEquivalent: 'MetalLB Load Balancer',
      },
      {
        id: 'd',
        text: 'Traefik',
        isCorrect: false,
        explanation: 'Traefik is an ingress controller for routing HTTP/HTTPS traffic.',
        nutanixEquivalent: 'Traefik Ingress',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'Gatekeeper (OPA) provides declarative admission control and compliance auditing to prevent insecure workloads from deploying.',
    deepExplanation: `Gatekeeper in NKP:
- Operates as a validating webhook intercepted by kube-apiserver.
- Uses ConstraintTemplates and Constraints written in Rego.
- Common rules: prevent privileged pods, enforce read-only root filesystems, require memory/CPU limits, and restrict image registries to internal Harbor/Artifactory.`,
  },
  {
    id: 'nkp-q43',
    badge: 'Identity & Access Management (IAM)',
    title: 'Applying LDAP Identity Provider Configuration in NKP',
    scenario:
      'An administrator needs to create an identity provider in NKP for Active Directory. The administrator prepares a configuration file `idp.yaml` with LDAP host, bind DN, and user search queries.',
    prompt: 'Which command will apply this configuration to the cluster?',
    options: [
      {
        id: 'a',
        text: 'nkp create idp ldap --config-file=idp.yaml',
        isCorrect: true,
        explanation: 'Correct! The NKP CLI command `nkp create idp ldap --config-file=idp.yaml` translates the LDAP specifications into a Dex connector and applies it to the cluster.',
        nutanixEquivalent: 'nkp create idp ldap --config-file=idp.yaml',
      },
      {
        id: 'b',
        text: 'nkp apply ldap-service --file idp.yaml',
        isCorrect: false,
        explanation: '`apply ldap-service` is not a valid NKP CLI command.',
        nutanixEquivalent: 'Invalid Command Syntax',
      },
      {
        id: 'c',
        text: 'kubectl create secret generic ldap --from-file idp.yaml',
        isCorrect: false,
        explanation: 'Creating a raw generic secret does not configure Dex connectors or update Kommander identity broker settings.',
        nutanixEquivalent: 'Unprocessed Raw Secret',
      },
      {
        id: 'd',
        text: 'nkp install ldap-connector idp.yaml',
        isCorrect: false,
        explanation: 'The command syntax requires `create idp <type>`.',
        nutanixEquivalent: 'Malformed Command',
      },
    ],
    correctOptionId: 'a',
    keyTakeaway: 'Use `nkp create idp ldap --config-file=idp.yaml` to register an external LDAP/Active Directory identity provider in NKP.',
    deepExplanation: `Dex LDAP Configuration:
- \`idp.yaml\` defines:
  - Host and port (typically LDAPS 636)
  - Bind DN and password
  - User and group search filters
- The command updates the Dex deployment in the management cluster and triggers a rolling reload to authenticate users immediately.`,
  },
  {
    id: 'nkp-q44',
    badge: 'Air-Gapped Deployment Sequencing',
    title: 'Next Step After Configuring Local Registry in Air-Gapped Setup',
    scenario:
      'An administrator has successfully configured the local registry and seeded it with the NKP image bundle for an air-gapped deployment of NKP.',
    prompt: 'What is the next step to complete the deployment?',
    options: [
      {
        id: 'a',
        text: 'Create the bootstrap cluster.',
        isCorrect: true,
        explanation: 'Correct! Once the local private registry is seeded with container images, the administrator initiates cluster creation by running `nkp create bootstrap` (or `nkp create cluster` which spawns the bootstrap cluster automatically).',
        nutanixEquivalent: 'Create Bootstrap Cluster (Kind)',
      },
      {
        id: 'b',
        text: 'Delete the bastion host.',
        isCorrect: false,
        explanation: 'The bastion host is actively executing the deployment; deleting it halts everything.',
        nutanixEquivalent: 'Premature Bastion Deletion',
      },
      {
        id: 'c',
        text: 'Deploy application Helm charts.',
        isCorrect: false,
        explanation: 'The Kubernetes cluster does not exist yet.',
        nutanixEquivalent: 'Premature Workload Deployment',
      },
      {
        id: 'd',
        text: 'Attach external clusters to Kommander.',
        isCorrect: false,
        explanation: 'Kommander cannot manage clusters until the management cluster is fully provisioned.',
        nutanixEquivalent: 'Missing Management Cluster',
      },
    ],
    correctOptionId: 'a',
    keyTakeaway: 'After private registry initialization and bundle pushing, the next procedural step is creating the bootstrap cluster to run Cluster API controllers.',
    deepExplanation: `Air-Gapped Provisioning Flow:
1. Bastion host preparation (Docker, packages).
2. Seed local image registry with Konvoy/Kommander bundles.
3. Launch Kind bootstrap cluster referencing the local registry mirrors.
4. CAPI provisions the target infrastructure VMs on Nutanix AHV.
5. Pivot CAPI management to target cluster and delete bootstrap.`,
  },
  {
    id: 'nkp-q45',
    badge: 'Infrastructure Providers & CAPI',
    title: 'Component Responsible for Orchestrating AHV VMs in NKP',
    scenario:
      'An administrator needs to deploy an NKP cluster on Nutanix AHV. A specific Cluster API provider communicates with Prism to create virtual machines and configure networks.',
    prompt: 'Which component is responsible for orchestrating the deployment of the VMs that will make up the cluster?',
    options: [
      {
        id: 'a',
        text: 'CAPA (Cluster API Provider AWS)',
        isCorrect: false,
        explanation: 'CAPA manages AWS EC2 instances and VPCs.',
        nutanixEquivalent: 'AWS Provider',
      },
      {
        id: 'b',
        text: 'CAPX (Cluster API Provider Nutanix)',
        isCorrect: true,
        explanation: 'Correct! CAPX is the Cluster API Provider for Nutanix. It interacts with the Nutanix Prism Central v3/v4 REST APIs to clone VM templates, attach vDisks, and configure network adapters for control plane and worker nodes.',
        nutanixEquivalent: 'Cluster API Provider Nutanix (CAPX)',
      },
      {
        id: 'c',
        text: 'CAPZ (Cluster API Provider Azure)',
        isCorrect: false,
        explanation: 'CAPZ manages Microsoft Azure resources.',
        nutanixEquivalent: 'Azure Provider',
      },
      {
        id: 'd',
        text: 'CAPV (Cluster API Provider vSphere)',
        isCorrect: false,
        explanation: 'CAPV manages VMware vSphere VMs.',
        nutanixEquivalent: 'vSphere Provider',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'CAPX (Cluster API Provider Nutanix) is the controller responsible for orchestrating VM creation, scaling, and lifecycle operations on Nutanix AHV.',
    deepExplanation: `CAPX Architecture:
- Implements the Kubernetes Cluster API specification for Nutanix AHV.
- Watches \`NutanixCluster\`, \`NutanixMachine\`, and \`NutanixMachineTemplate\` CRDs.
- Talks directly to Prism Central to provision VMs from pre-baked Nutanix Image Service disk images.`,
  },
  {
    id: 'nkp-q46',
    badge: 'Prism Central RBAC & Credentials',
    title: 'Required Prism Central Role for User Account in Nutanix Credentials',
    scenario:
      'An administrator is preparing to install NKP on Nutanix AHV and needs to configure service credentials for Prism Central.',
    prompt: 'Which Prism Central role or permission level is required for the service account?',
    options: [
      {
        id: 'a',
        text: 'Viewer Only',
        isCorrect: false,
        explanation: 'Read-only access cannot create VMs, allocate storage disks, or configure network subnets.',
        nutanixEquivalent: 'Prism Viewer Role',
      },
      {
        id: 'b',
        text: 'Cluster Admin / Prism Central Admin with VM and Network management rights',
        isCorrect: true,
        explanation: 'Correct! The service account used by CAPX must have Prism Central Administrator permissions (or custom RBAC with full VM lifecycle, image cloning, storage container provisioning, and IPAM management rights).',
        nutanixEquivalent: 'Prism Central Administrator / Custom Infrastructure Role',
      },
      {
        id: 'c',
        text: 'Self-Service Consumer',
        isCorrect: false,
        explanation: 'Self-service consumer lacks API rights to configure low-level hypervisor attributes required by CAPI.',
        nutanixEquivalent: 'Self-Service Portal Role',
      },
      {
        id: 'd',
        text: 'Backup Operator',
        isCorrect: false,
        explanation: 'Backup operators have snapshot rights only, not VM creation and network assignment rights.',
        nutanixEquivalent: 'Backup Operator Role',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'The Prism Central credentials provided to NKP require administrative permissions to create, configure, power on, and delete virtual machines and virtual disks.',
    deepExplanation: `Prism Central Service Account Requirements:
- Needs access to:
  - VM Management (Create, Delete, Power, Update Specs)
  - Image Management (Clone from Image Service)
  - Subnet/VLAN mapping
  - Storage Container allocation
- Nutanix recommends a dedicated service account assigned to the Prism Central Admin role.`,
  },
  {
    id: 'nkp-q47',
    badge: 'High Availability & Networking',
    title: 'Primary Function of kube-vip in NKP AHV Deployments',
    scenario: 'What is the primary function of the kube-vip component in an NKP cluster deployed on Nutanix AHV?',
    prompt: 'What is the primary function of the kube-vip component in an NKP cluster deployed on Nutanix AHV?',
    options: [
      {
        id: 'a',
        text: 'Provide persistent storage encryption across nodes.',
        isCorrect: false,
        explanation: 'Storage encryption is performed by Nutanix AOS at rest.',
        nutanixEquivalent: 'AOS Data-at-Rest Encryption',
      },
      {
        id: 'b',
        text: 'Provide a virtual IP address and load balancer for the Kubernetes API server control plane.',
        isCorrect: true,
        explanation: 'Correct! kube-vip provides a lightweight, software-defined Virtual IP (VIP) and Layer-2 ARP/BGP leader election for the Kubernetes control plane API server (port 6443) on bare-metal and AHV without requiring external hardware load balancers.',
        nutanixEquivalent: 'kube-vip Control Plane Load Balancer & VIP',
      },
      {
        id: 'c',
        text: 'Manage container image garbage collection.',
        isCorrect: false,
        explanation: 'Container image cleanup is managed by kubelet.',
        nutanixEquivalent: 'Kubelet Image GC',
      },
      {
        id: 'd',
        text: 'Synchronize system clocks using NTP.',
        isCorrect: false,
        explanation: 'Clock synchronization uses chrony/systemd-timesyncd.',
        nutanixEquivalent: 'System Time Synchronization',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'kube-vip delivers a highly available virtual IP address for the Kubernetes API server on Nutanix AHV control plane nodes.',
    deepExplanation: `kube-vip Operation:
- Deployed as a static pod on each control plane node.
- Uses Raft-like leader election via Kubernetes coordination leases or ARP broadcasting.
- Ensures all worker nodes, kubectl clients, and management controllers send API traffic to a single resilient IP address.`,
  },
  {
    id: 'nkp-q48',
    badge: 'Upgrade Lifecycle & Operations',
    title: 'Recommended Upgrade Sequencing for NKP Environment',
    scenario:
      'An administrator needs to upgrade an enterprise NKP environment consisting of a Kommander management cluster and several managed workload clusters.',
    prompt: 'What is the recommended upgrade order?',
    options: [
      {
        id: 'a',
        text: 'Upgrade all workload clusters first, then upgrade the management cluster.',
        isCorrect: false,
        explanation: 'Upgrading workload clusters first can create API incompatibilities where an older management plane cannot manage newer CAPI and Kubernetes schemas.',
        nutanixEquivalent: 'Reverse Upgrade Sequencing',
      },
      {
        id: 'b',
        text: 'Upgrade the management cluster first, then the workload clusters.',
        isCorrect: true,
        explanation: 'Correct! Always upgrade the management cluster (and Kommander) first. Once the management controllers support the newer Kubernetes and CAPI APIs, upgrade the managed workload clusters one by one.',
        nutanixEquivalent: 'Top-Down Upgrade: Management Cluster First, Then Workload Clusters',
      },
      {
        id: 'c',
        text: 'Upgrade the workload clusters and delete the management cluster.',
        isCorrect: false,
        explanation: 'Deleting the management cluster destroys multi-cluster orchestration and monitoring.',
        nutanixEquivalent: 'Destructive Teardown',
      },
      {
        id: 'd',
        text: 'Upgrade worker nodes only, leaving control plane nodes on older versions.',
        isCorrect: false,
        explanation: 'Kubernetes version skew policy strictly requires control plane nodes to be equal to or newer than worker nodes.',
        nutanixEquivalent: 'Version Skew Violation',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'Always upgrade the management cluster first so newer CAPI controllers and Kommander CRDs can safely coordinate the subsequent upgrade of workload clusters.',
    deepExplanation: `NKP Upgrade Lifecycle Rules:
1. **Management Plane First**: Upgrade the NKP CLI binary on the bastion, then upgrade the management cluster control plane and Kommander platform apps.
2. **Workload Clusters Second**: Rolling upgrade of workload cluster control plane nodes followed by worker node pools using \`nkp upgrade cluster\`.
3. Ensures adherence to Kubernetes version skew policies (worker nodes must not exceed control plane versions).`,
  },
  {
    id: 'nkp-q49',
    badge: 'Container Network Interface (CNI)',
    title: 'Default CNI Plugin in Standard NKP Deployments',
    scenario: 'In standard Nutanix Kubernetes Platform (NKP) deployments, which default CNI plugin is deployed for pod networking?',
    prompt: 'What is the default CNI plugin used for cluster networking?',
    options: [
      {
        id: 'a',
        text: 'Flannel',
        isCorrect: false,
        explanation: 'Flannel provides simple overlay networking without native network policy enforcement.',
        nutanixEquivalent: 'Flannel CNI',
      },
      {
        id: 'b',
        text: 'Calico',
        isCorrect: true,
        explanation: 'Correct! Calico is the standard, default CNI plugin deployed in NKP for robust pod IPAM, IP-in-IP/VXLAN encapsulation, and declarative Kubernetes NetworkPolicy enforcement.',
        nutanixEquivalent: 'Calico CNI (Default Pod Networking & NetworkPolicy Engine)',
      },
      {
        id: 'c',
        text: 'Weave Net',
        isCorrect: false,
        explanation: 'Weave Net is deprecated and not shipped with NKP.',
        nutanixEquivalent: 'Deprecated CNI',
      },
      {
        id: 'd',
        text: 'AWS VPC CNI',
        isCorrect: false,
        explanation: 'AWS VPC CNI is cloud-specific and not used on on-premises Nutanix AHV deployments.',
        nutanixEquivalent: 'Cloud Vendor CNI',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'Calico is the default CNI plugin in NKP, providing high-performance routing and full Kubernetes NetworkPolicy security enforcement.',
    deepExplanation: `Calico in NKP:
- Handles IP address management (IPAM) for pods using non-conflicting pools.
- Uses BGP or overlay (VXLAN/IP-in-IP) to route traffic between worker nodes.
- Enforces ingress and egress network security policies at the Linux kernel packet filtering level.`,
  },
  {
    id: 'nkp-q50',
    badge: 'Dynamic Persistent Storage',
    title: 'Component Enabling Dynamic Volume Provisioning on Nutanix Storage',
    scenario:
      'An administrator is deploying an NKP cluster and wants to ensure that persistent volumes are dynamically provisioned using Nutanix enterprise storage.',
    prompt: 'Which component enables this functionality?',
    options: [
      {
        id: 'a',
        text: 'Nutanix CSI Driver',
        isCorrect: true,
        explanation: 'Correct! The Nutanix Container Storage Interface (CSI) Driver connects Kubernetes PersistentVolumeClaims (PVCs) directly to Nutanix Volumes (block via iSCSI) and Nutanix Files (file via NFS).',
        nutanixEquivalent: 'Nutanix CSI Driver (csi.nutanix.com)',
      },
      {
        id: 'b',
        text: 'Nutanix Move',
        isCorrect: false,
        explanation: 'Nutanix Move is a VM migration appliance, not a Kubernetes storage driver.',
        nutanixEquivalent: 'Nutanix Move Migration Appliance',
      },
      {
        id: 'c',
        text: 'Prism Central Image Service',
        isCorrect: false,
        explanation: 'Image Service manages VM disk images (qcow2, ISO), not persistent storage claims.',
        nutanixEquivalent: 'Prism Image Service',
      },
      {
        id: 'd',
        text: 'kube-proxy',
        isCorrect: false,
        explanation: 'kube-proxy routes network traffic for Kubernetes Services, having no role in storage.',
        nutanixEquivalent: 'kube-proxy Network Service',
      },
    ],
    correctOptionId: 'a',
    keyTakeaway: 'The Nutanix CSI Driver enables dynamic provisioning, snapshotting, and volume expansion of Nutanix Volumes and Files for Kubernetes workloads.',
    deepExplanation: `Nutanix CSI Capabilities:
- Dynamic Volume Provisioning: Creates Volume Groups on Prism Element on demand when PVC is submitted.
- Volume Expansion: Resizes volumes online without pod restarts.
- Snapshot & Restore: Leverages VolumeSnapshot CRDs integrated with Nutanix native snapshots.`,
  },
  {
    id: 'nkp-q51',
    badge: 'GitOps Engine & Continuous Delivery',
    title: 'GitOps Engine Providing Multi-Cluster Continuous Delivery in NKP',
    scenario:
      'A DevOps team wants to deploy applications to multiple NKP clusters using a GitOps approach, synchronizing state with a Git repository.',
    prompt: 'Which NKP component provides this GitOps capability?',
    options: [
      {
        id: 'a',
        text: 'Flux',
        isCorrect: true,
        explanation: 'Correct! Flux is the built-in GitOps engine in NKP and Kommander that continually reconciles Helm charts, Git repositories, and Kustomizations across all managed clusters.',
        nutanixEquivalent: 'Flux GitOps Controller (source-controller, helm-controller)',
      },
      {
        id: 'b',
        text: 'Jenkins',
        isCorrect: false,
        explanation: 'Jenkins is a standalone CI engine, not the declarative GitOps operator embedded in NKP.',
        nutanixEquivalent: 'Jenkins CI',
      },
      {
        id: 'c',
        text: 'Ansible',
        isCorrect: false,
        explanation: 'Ansible is an imperative configuration tool used by Image Builder, not the runtime in-cluster GitOps controller.',
        nutanixEquivalent: 'Ansible Configuration Tool',
      },
      {
        id: 'd',
        text: 'Terraform',
        isCorrect: false,
        explanation: 'Terraform is an infrastructure provisioning tool, not an in-cluster GitOps reconciliation daemon.',
        nutanixEquivalent: 'Terraform IaC',
      },
    ],
    correctOptionId: 'a',
    keyTakeaway: 'Flux is the embedded GitOps controller in NKP, automatically reconciling Helm releases and Kubernetes manifests from Git repositories across clusters.',
    deepExplanation: `Flux GitOps in NKP:
- Runs in the \`kommander-flux\` namespace.
- Continuously polls Git/OCI sources for changes and reconciles them using declarative \`HelmRelease\` and \`Kustomization\` custom resources.
- If changes occur directly in a cluster (configuration drift), Flux reverts the cluster to match the declared Git state.`,
  },
  {
    id: 'nkp-q52',
    badge: 'Disaster Recovery & Workload Protection',
    title: 'Default Workload Backup and Disaster Recovery Solution in NKP',
    scenario: 'An administrator needs to back up workloads and persistent volume data running on an NKP cluster.',
    prompt: 'Which default backup and restore tool is integrated with NKP?',
    options: [
      {
        id: 'a',
        text: 'Restic only',
        isCorrect: false,
        explanation: 'Restic is used as a file-level helper within Velero, but Velero is the overarching orchestrator.',
        nutanixEquivalent: 'Restic Plugin',
      },
      {
        id: 'b',
        text: 'Velero',
        isCorrect: true,
        explanation: 'Correct! Velero is the enterprise backup, disaster recovery, and cluster migration tool integrated into NKP to protect Kubernetes metadata, namespaces, and persistent volume snapshots.',
        nutanixEquivalent: 'Velero Backup & Disaster Recovery Platform App',
      },
      {
        id: 'c',
        text: 'Nutanix Mine only',
        isCorrect: false,
        explanation: 'Nutanix Mine is a hardware backup appliance, not the Kubernetes-native API backup operator.',
        nutanixEquivalent: 'Nutanix Mine Appliance',
      },
      {
        id: 'd',
        text: 'rsync',
        isCorrect: false,
        explanation: 'rsync is a file sync utility, not a Kubernetes application-consistent backup solution.',
        nutanixEquivalent: 'Command-line File Sync',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'Velero is the native platform application in NKP responsible for backing up cluster manifests, secrets, and persistent volume snapshots to S3 storage.',
    deepExplanation: `Velero Integration:
- Backs up Kubernetes API objects (Deployments, StatefulSets, Secrets, ConfigMaps).
- Uses CSI VolumeSnapshot plugins to trigger atomic hardware-level snapshots of Nutanix Volumes.
- Stores backups in Nutanix Objects (S3-compatible) or public cloud buckets.`,
  },
  {
    id: 'nkp-q53',
    badge: 'Image Builder & Node Customization',
    title: 'Purpose of Nutanix Image Builder (NIB) in NKP',
    scenario: 'What is the purpose of the Nutanix Image Builder (NIB) in an NKP deployment?',
    prompt: 'What is the purpose of the Nutanix Image Builder (NIB) in an NKP deployment?',
    options: [
      {
        id: 'a',
        text: 'To generate synthetic user traffic for stress testing.',
        isCorrect: false,
        explanation: 'NIB does not perform application load testing.',
        nutanixEquivalent: 'Load Testing Engine',
      },
      {
        id: 'b',
        text: 'To create customized OS machine images containing Kubernetes binaries, containerd, and required packages for AHV and other clouds.',
        isCorrect: true,
        explanation: 'Correct! Nutanix Image Builder (NIB / Konvoy Image Builder) builds hardened, pre-configured VM disk images (qcow2, AMI, OVA) containing the specific Kubernetes version, containerd, and prerequisites required by Cluster API.',
        nutanixEquivalent: 'Nutanix Image Builder (NIB / KIB)',
      },
      {
        id: 'c',
        text: 'To compile application source code into container images.',
        isCorrect: false,
        explanation: 'Building application container images is performed by developer CI/CD pipelines, not NIB.',
        nutanixEquivalent: 'Application CI/CD Pipeline',
      },
      {
        id: 'd',
        text: 'To manage DNS resolution for pods across clusters.',
        isCorrect: false,
        explanation: 'DNS resolution is handled by CoreDNS and ExternalDNS.',
        nutanixEquivalent: 'CoreDNS Service',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'Nutanix Image Builder (NIB) produces pre-configured and hardened OS machine images (qcow2) containing all required Kubernetes binaries and drivers for AHV deployment.',
    deepExplanation: `NIB Workflow:
- Uses Packer and Ansible playbooks under the hood.
- Boots a base Linux ISO (RHEL, Rocky, Ubuntu).
- Installs containerd, kubeadm, kubelet, Nutanix storage prerequisites, and pre-caches Kubernetes control plane container images to accelerate provisioning.`,
  },
  {
    id: 'nkp-q54',
    badge: 'Centralized Log Aggregation',
    title: 'Centralized Log Aggregation Stack in NKP',
    scenario:
      'An administrator wants to view logs from all pods across multiple NKP clusters from a single centralized dashboard.',
    prompt: 'Which combination of tools provides this functionality in NKP?',
    options: [
      {
        id: 'a',
        text: 'Grafana Loki and Fluent Bit',
        isCorrect: true,
        explanation: 'Correct! Fluent Bit collects and ships container logs from worker nodes on each cluster, while Grafana Loki indexes and stores logs centrally for unified query and visualization in Grafana.',
        nutanixEquivalent: 'Fluent Bit Log Collector + Grafana Loki Centralized Storage',
      },
      {
        id: 'b',
        text: 'Prometheus and Alertmanager',
        isCorrect: false,
        explanation: 'Prometheus and Alertmanager handle numeric time-series metrics and alerts, not log indexing.',
        nutanixEquivalent: 'Metrics Pipeline',
      },
      {
        id: 'c',
        text: 'Traefik and Dex',
        isCorrect: false,
        explanation: 'Traefik and Dex handle ingress routing and identity authentication, respectively.',
        nutanixEquivalent: 'Ingress and Identity',
      },
      {
        id: 'd',
        text: 'Gatekeeper and Rook-Ceph',
        isCorrect: false,
        explanation: 'Gatekeeper enforces admission policies and Rook-Ceph manages block/file storage pools.',
        nutanixEquivalent: 'Security and Storage',
      },
    ],
    correctOptionId: 'a',
    keyTakeaway: 'Fluent Bit (log collection) and Grafana Loki (log aggregation and indexing) form the native centralized logging stack in NKP.',
    deepExplanation: `Logging Architecture:
- **Fluent Bit DaemonSet**: Runs on every node in every managed cluster, scraping container stdout/stderr logs from \`/var/log/pods\`.
- **Loki**: Stores compressed log streams indexed by labels (\`cluster\`, \`namespace\`, \`pod\`, \`container\`).
- **Grafana**: Allows administrators to correlate Loki logs with Prometheus metrics in unified split-screen views.`,
  },
  {
    id: 'nkp-q55',
    badge: 'Air-Gapped Container Delivery',
    title: 'Container Image Availability in Air-Gapped Deployments',
    scenario:
      'In an air-gapped NKP deployment where nodes have no internet access, how are required container images made available to the cluster nodes?',
    prompt: 'How are container images made available to the cluster nodes?',
    options: [
      {
        id: 'a',
        text: 'Nodes pull images dynamically over public HTTPS.',
        isCorrect: false,
        explanation: 'Air-gapped nodes are physically or firewalled disconnected from the public internet.',
        nutanixEquivalent: 'Direct Internet Access',
      },
      {
        id: 'b',
        text: 'By seeding an internal enterprise container registry (e.g., Harbor) from the NKP air-gapped bundle and configuring registry mirrors.',
        isCorrect: true,
        explanation: 'Correct! The administrator uploads the air-gapped tarball bundle, pushes images to an internal registry using `nkp push bundle`, and configures containerd registry mirror settings so nodes pull locally.',
        nutanixEquivalent: 'Seeded Enterprise Registry Mirror (Harbor/Artifactory)',
      },
      {
        id: 'c',
        text: 'By manually copying docker images to every node using USB drives.',
        isCorrect: false,
        explanation: 'Manual per-node USB loading is error-prone, insecure, and unscalable across enterprise clusters.',
        nutanixEquivalent: 'Manual Per-Node Copying',
      },
      {
        id: 'd',
        text: 'By disabling container image verification in Kubernetes.',
        isCorrect: false,
        explanation: 'Disabling verification does not resolve missing image bits.',
        nutanixEquivalent: 'Image Verification Bypass',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'In air-gapped clusters, an internal registry is seeded with the NKP image bundle, and cluster nodes are configured with registry mirror endpoints.',
    deepExplanation: `Air-Gapped Image Distribution:
- Command: \`nkp push bundle --bundle <tarball> --to-registry <internal-registry>\`
- Containerd on all provisioned nodes is configured via cloud-init to redirect requests for \`docker.io\`, \`quay.io\`, and \`registry.k8s.io\` to the local registry endpoint.`,
  },
  {
    id: 'nkp-q56',
    badge: 'Cluster Lifecycle Management (CAPI)',
    title: 'Role of Cluster API (CAPI) in Nutanix Kubernetes Platform',
    scenario: 'What is the role of Cluster API (CAPI) in Nutanix Kubernetes Platform?',
    prompt: 'What is the role of Cluster API (CAPI) in Nutanix Kubernetes Platform?',
    options: [
      {
        id: 'a',
        text: 'To replace Kubernetes RBAC with basic HTTP auth.',
        isCorrect: false,
        explanation: 'CAPI does not alter Kubernetes authorization mechanisms.',
        nutanixEquivalent: 'Authentication Modification',
      },
      {
        id: 'b',
        text: 'To manage the lifecycle (creation, scaling, rolling upgrades, and deletion) of Kubernetes clusters using declarative Kubernetes-style APIs.',
        isCorrect: true,
        explanation: 'Correct! Cluster API (CAPI) is the Kubernetes sub-project that treats cluster infrastructure (machines, control planes, node pools) as declarative Kubernetes Custom Resources, enabling declarative lifecycle management.',
        nutanixEquivalent: 'Cluster API (CAPI) Declarative Infrastructure Management',
      },
      {
        id: 'c',
        text: 'To serve as an API gateway for end-user web applications.',
        isCorrect: false,
        explanation: 'CAPI manages infrastructure, not application web traffic routing.',
        nutanixEquivalent: 'API Gateway Proxy',
      },
      {
        id: 'd',
        text: 'To provision software-defined routers between VPCs.',
        isCorrect: false,
        explanation: 'VPC routing is managed by cloud/hypervisor networking, not CAPI.',
        nutanixEquivalent: 'Software Router',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'Cluster API (CAPI) provides declarative, Kubernetes-native management of cluster lifecycle operations including creation, scaling, and rolling upgrades.',
    deepExplanation: `Cluster API Primitives:
- \`Cluster\`: Defines global networking, CNI, and control plane endpoint.
- \`KubeadmControlPlane\`: Governs control plane node versions and rolling upgrades.
- \`MachineDeployment\`: Manages worker node pools with rolling updates and autoscaling.
- \`MachineHealthCheck\`: Automatically detects unhealthy nodes and remediates them by replacing VMs.`,
  },
  {
    id: 'nkp-q57',
    badge: 'Storage Fabric & Protocols',
    title: 'Protocol Used by Nutanix CSI Driver for Block Volumes on AHV',
    scenario:
      'An administrator is configuring storage for stateful applications on an NKP cluster running on Nutanix AHV using Nutanix Volumes.',
    prompt: 'Which storage protocol is used by the Nutanix CSI driver to attach block volumes to worker nodes?',
    options: [
      {
        id: 'a',
        text: 'iSCSI',
        isCorrect: true,
        explanation: 'Correct! The Nutanix CSI driver uses iSCSI (connecting to the Nutanix Data Services IP) to attach Nutanix Volumes block storage targets to worker node virtual machines.',
        nutanixEquivalent: 'iSCSI Block Protocol via Nutanix Data Services IP',
      },
      {
        id: 'b',
        text: 'Fibre Channel (FC)',
        isCorrect: false,
        explanation: 'Nutanix AHV is a hyperconverged architecture that does not use Fibre Channel SAN switches.',
        nutanixEquivalent: 'Fibre Channel SAN',
      },
      {
        id: 'c',
        text: 'FTP',
        isCorrect: false,
        explanation: 'FTP is a legacy file transfer protocol, not a block storage protocol.',
        nutanixEquivalent: 'FTP Protocol',
      },
      {
        id: 'd',
        text: 'SMB 1.0',
        isCorrect: false,
        explanation: 'SMB is a Windows file sharing protocol, not used for Linux block persistent volumes.',
        nutanixEquivalent: 'SMB File Protocol',
      },
    ],
    correctOptionId: 'a',
    keyTakeaway: 'The Nutanix CSI Driver attaches block storage volumes to worker nodes over iSCSI directed to the Nutanix Data Services IP.',
    deepExplanation: `Nutanix CSI Block Storage Architecture:
- Nutanix Volumes presents Volume Groups as iSCSI targets.
- Worker nodes run the \`iscsid\` initiator service.
- The Nutanix CSI node plugin logs into the iSCSI target over the virtual switch network and formats the block device with ext4 or xfs for the pod.`,
  },
  {
    id: 'nkp-q58',
    badge: 'Cluster Access & Kubeconfig',
    title: 'Generating Kubeconfig for Managed Workload Cluster',
    scenario: 'An administrator needs to obtain direct kubectl access to a newly provisioned managed workload cluster.',
    prompt: 'Which command is used to retrieve the kubeconfig file for a managed cluster from the management cluster?',
    options: [
      {
        id: 'a',
        text: 'nkp get kubeconfig --cluster-name <cluster-name>',
        isCorrect: true,
        explanation: 'Correct! The command `nkp get kubeconfig --cluster-name <cluster-name>` extracts the administrative kubeconfig secret from the management cluster and writes it locally for kubectl access.',
        nutanixEquivalent: 'nkp get kubeconfig --cluster-name <cluster-name>',
      },
      {
        id: 'b',
        text: 'kubectl pull-config <cluster-name>',
        isCorrect: false,
        explanation: '`pull-config` is not a kubectl command.',
        nutanixEquivalent: 'Invalid Command',
      },
      {
        id: 'c',
        text: 'nkp export credentials <cluster-name>',
        isCorrect: false,
        explanation: '`export credentials` is not the sub-command used for kubeconfig generation.',
        nutanixEquivalent: 'Invalid Sub-command',
      },
      {
        id: 'd',
        text: 'cat /etc/kubernetes/admin.conf on bastion',
        isCorrect: false,
        explanation: 'The bastion host does not run the Kubernetes control plane for remote workload clusters.',
        nutanixEquivalent: 'Local Bastion Config',
      },
    ],
    correctOptionId: 'a',
    keyTakeaway: 'Use `nkp get kubeconfig --cluster-name <cluster-name>` to retrieve the administrative credentials for a managed cluster.',
    deepExplanation: `Kubeconfig Retrieval:
- In Cluster API, each managed cluster generates a secret named \`<cluster-name>-kubeconfig\` in the management cluster.
- \`nkp get kubeconfig\` extracts this secret, decodes the base64 certificate and token data, and outputs a ready-to-use configuration file.`,
  },
  {
    id: 'nkp-q59',
    badge: 'Network Policy Enforcement',
    title: 'Component Enforcing Kubernetes NetworkPolicies in NKP',
    scenario:
      'A platform engineer creates a Kubernetes NetworkPolicy to restrict ingress traffic into a database pod to only pods with label `role: frontend`.',
    prompt: 'Which component is responsible for enforcing these network rules on the nodes?',
    options: [
      {
        id: 'a',
        text: 'The CNI plugin (e.g. Calico)',
        isCorrect: true,
        explanation: 'Correct! In Kubernetes and NKP, NetworkPolicies are implemented and enforced at the node network packet filter level (iptables/eBPF) by the active CNI plugin (such as Calico).',
        nutanixEquivalent: 'CNI NetworkPolicy Enforcement Engine (Calico Felix/eBPF)',
      },
      {
        id: 'b',
        text: 'Traefik Ingress Controller',
        isCorrect: false,
        explanation: 'Traefik operates at the application Layer 7 for external ingress, not East-West pod-to-pod Layer 3/4 filtering.',
        nutanixEquivalent: 'Layer 7 Ingress Proxy',
      },
      {
        id: 'c',
        text: 'CoreDNS',
        isCorrect: false,
        explanation: 'CoreDNS resolves hostnames to IPs and does not perform packet filtering.',
        nutanixEquivalent: 'DNS Resolution Service',
      },
      {
        id: 'd',
        text: 'Prism Central Flow Network Security',
        isCorrect: false,
        explanation: 'Flow Network Security enforces hypervisor VM-level microsegmentation, whereas Kubernetes pod NetworkPolicies are enforced inside the nodes by the CNI.',
        nutanixEquivalent: 'Prism Central Flow (VM-Level Microsegmentation)',
      },
    ],
    correctOptionId: 'a',
    keyTakeaway: 'Kubernetes NetworkPolicies are enforced inside the cluster nodes by the CNI plugin (Calico) manipulating Linux iptables or eBPF.',
    deepExplanation: `NetworkPolicy Enforcement Mechanics:
- Kubernetes API Server stores \`NetworkPolicy\` objects.
- Calico agent (Felix) watches the API server and compiles NetworkPolicies into kernel-level iptables rules or eBPF programs on each node interface.
- Traffic violating the policy is dropped before reaching the target pod's veth interface.`,
  },
  {
    id: 'nkp-q60',
    badge: 'Multi-Cluster Project Multi-Tenancy',
    title: 'Architectural Scope of a Kommander Project',
    scenario: 'What is the architectural scope and purpose of a Project in Kommander?',
    prompt: 'What is the scope of a Project in Kommander?',
    options: [
      {
        id: 'a',
        text: 'A Project represents an entire physical Nutanix AHV datacenter.',
        isCorrect: false,
        explanation: 'Datacenters and clusters are physical infrastructure, not project boundaries.',
        nutanixEquivalent: 'Physical Datacenter Boundary',
      },
      {
        id: 'b',
        text: 'A Project groups one or more Kubernetes namespaces across one or more clusters within a Workspace, providing multi-cluster namespace isolation and resource quotas.',
        isCorrect: true,
        explanation: 'Correct! In Kommander hierarchy, a Workspace contains Projects. A Project groups corresponding namespaces across multiple member clusters, applying uniform quotas and developer RBAC.',
        nutanixEquivalent: 'Kommander Project (Federated Multi-Cluster Namespace Isolation)',
      },
      {
        id: 'c',
        text: 'A Project is restricted to a single pod running in kube-system.',
        isCorrect: false,
        explanation: 'A pod is an individual container instance, not a multi-tenant administrative boundary.',
        nutanixEquivalent: 'Single Pod Instance',
      },
      {
        id: 'd',
        text: 'A Project is a replacement for Git repositories.',
        isCorrect: false,
        explanation: 'Projects do not host Git repositories; they consume Git repositories via Flux.',
        nutanixEquivalent: 'Git Code Repository',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'A Kommander Project groups namespaces across multiple clusters within a workspace, establishing developer isolation and multi-cluster resource quotas.',
    deepExplanation: `Kommander Multi-Tenancy Hierarchy:
1. **Global**: Entire management cluster and all workspaces.
2. **Workspace**: Multi-cluster grouping for business units or environments (e.g. Production, Staging).
3. **Project**: Application team boundary within a workspace. When created, Kommander provisions the project's namespace on all designated clusters and federates RoleBindings and ResourceQuotas.`,
  },
];
