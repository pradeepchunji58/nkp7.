import React from 'react';
import {
  Server,
  Sparkles,
  Volume2,
  BookOpen,
  ClipboardList,
  Layers,
  HelpCircle,
  ShieldCheck,
  Download,
  Monitor
} from 'lucide-react';

export type NavTab = 'exam-question' | 'deep-dive' | 'architecture' | 'prerequisites' | 'practice-mode' | 'ask-ai' | 'local-setup';

interface HeaderProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  currentQuestionIndex: number;
  totalQuestions: number;
  isAudioPlaying: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onSelectTab,
  currentQuestionIndex,
  totalQuestions,
  isAudioPlaying,
}) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-40 shadow-sm">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between py-4 gap-4">
          {/* Brand & Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center text-slate-950 font-black text-lg shadow-md flex-shrink-0">
              <Server className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1">
                  Nutanix Kubernetes Platform
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 border border-slate-700 text-slate-300 font-mono">
                  NKP v2.x
                </span>
              </div>
              <h1 className="text-base sm:text-lg font-bold text-white tracking-tight">
                Bastion Host Examiner & Architecture Guide
              </h1>
            </div>
          </div>

          {/* Actions & TTS Status */}
          <div className="flex items-center gap-2.5 self-start md:self-auto flex-wrap">
            {/* Direct Export ZIP Download */}
            <a
              href="/api/download-zip"
              download="nkp-exam-app.zip"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white transition-all shadow-sm active:scale-95 cursor-pointer"
              title="Download project ZIP to run locally on Windows / Mac / Linux"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Code (.zip)</span>
            </a>

            {/* AI TTS Feature Badge */}
            <div
              className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-medium border transition-colors ${
                isAudioPlaying
                  ? 'bg-emerald-500/20 border-emerald-400 text-emerald-300 animate-pulse'
                  : 'bg-slate-800 border-slate-700 text-slate-300'
              }`}
            >
              <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
              <span className="font-semibold">Gemini 3.1 Flash TTS</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center gap-1 overflow-x-auto pb-2 scrollbar-none text-xs font-medium border-t border-slate-800/80 pt-2">
          <button
            onClick={() => onSelectTab('exam-question')}
            className={`px-3 py-2 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'exam-question' || activeTab === 'practice-mode'
                ? 'bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>NKP Exam Questions ({totalQuestions})</span>
          </button>

          <button
            onClick={() => onSelectTab('deep-dive')}
            className={`px-3 py-2 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'deep-dive'
                ? 'bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Architectural Explanations</span>
          </button>

          <button
            onClick={() => onSelectTab('architecture')}
            className={`px-3 py-2 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'architecture'
                ? 'bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Deployment Topology</span>
          </button>

          <button
            onClick={() => onSelectTab('prerequisites')}
            className={`px-3 py-2 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'prerequisites'
                ? 'bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <ClipboardList className="w-3.5 h-3.5" />
            <span>Bastion Prerequisites</span>
          </button>

          <button
            onClick={() => onSelectTab('local-setup')}
            className={`px-3 py-2 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'local-setup'
                ? 'bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Monitor className="w-3.5 h-3.5 text-emerald-400" />
            <span>Windows Setup</span>
          </button>

          <button
            onClick={() => onSelectTab('ask-ai')}
            className={`px-3 py-2 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 ${
              activeTab === 'ask-ai'
                ? 'bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>Ask AI Assistant</span>
          </button>
        </nav>
      </div>
    </header>
  );
};
