import React, { useState, useEffect } from 'react';
import {
  Server,
  Sparkles,
  Volume2,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  BookOpen,
  ClipboardList,
  Layers,
  ArrowRight,
  Info
} from 'lucide-react';
import { NKP_QUESTIONS } from './data/nkpQuestions';
import { OptionKey } from './types';
import { audioService } from './utils/audioPlayer';
import { Header, NavTab } from './components/Header';
import { QuestionCard } from './components/QuestionCard';
import { ExplanationDrawer } from './components/ExplanationDrawer';
import { ArchitectureDiagram } from './components/ArchitectureDiagram';
import { PrerequisitesChecklist } from './components/PrerequisitesChecklist';
import { AskAIAssistant } from './components/AskAIAssistant';
import { LocalSetupGuide } from './components/LocalSetupGuide';
import { AudioPlayerBar } from './components/AudioPlayerBar';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('exam-question');
  const [questionIndex, setQuestionIndex] = useState<number>(0);
  const [userAnswers, setUserAnswers] = useState<Record<string, { selected: OptionKey | null; isSubmitted: boolean }>>({
    'nkp-q1': { selected: null, isSubmitted: false },
  });
  const [isAudioPlaying, setIsAudioPlaying] = useState<boolean>(false);

  const currentQuestion = NKP_QUESTIONS[questionIndex] || NKP_QUESTIONS[0];
  const currentState = userAnswers[currentQuestion.id] || { selected: null, isSubmitted: false };

  useEffect(() => {
    const unsub = audioService.subscribe((state) => {
      setIsAudioPlaying(state.isPlaying);
    });
    return unsub;
  }, []);

  const handleSelectOption = (key: OptionKey) => {
    setUserAnswers((prev) => ({
      ...prev,
      [currentQuestion.id]: {
        selected: key,
        isSubmitted: false,
      },
    }));
  };

  const handleSubmit = () => {
    if (!currentState.selected) return;
    setUserAnswers((prev) => ({
      ...prev,
      [currentQuestion.id]: {
        ...currentState,
        isSubmitted: true,
      },
    }));
  };

  const handleReset = () => {
    setUserAnswers((prev) => ({
      ...prev,
      [currentQuestion.id]: {
        selected: null,
        isSubmitted: false,
      },
    }));
  };

  const handleNextQuestion = () => {
    if (questionIndex < NKP_QUESTIONS.length - 1) {
      setQuestionIndex(questionIndex + 1);
    }
  };

  const handlePrevQuestion = () => {
    if (questionIndex > 0) {
      setQuestionIndex(questionIndex - 1);
    }
  };

  const answeredCount = (Object.values(userAnswers) as { selected: OptionKey | null; isSubmitted: boolean }[]).filter(
    (a) => a.isSubmitted
  ).length;
  const correctCount = (Object.entries(userAnswers) as [string, { selected: OptionKey | null; isSubmitted: boolean }][]).filter(
    ([id, a]) => a.isSubmitted && a.selected === NKP_QUESTIONS.find((q) => q.id === id)?.correctOptionId
  ).length;

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 flex flex-col font-sans antialiased pb-28">
      {/* Sticky Top Header */}
      <Header
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        currentQuestionIndex={questionIndex}
        totalQuestions={NKP_QUESTIONS.length}
        isAudioPlaying={isAudioPlaying}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-8">
        {/* Quick Context Banner */}
        <div className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start sm:items-center gap-3.5">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-600 flex items-center justify-center flex-shrink-0">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-800">
                  Topic: Nutanix Kubernetes Platform (NKP)
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 font-semibold">
                  Exam Objectives & Architecture ({NKP_QUESTIONS.length} Questions)
                </span>
              </div>
              <p className="text-xs text-slate-600 mt-0.5">
                Practice with comprehensive real-world exam questions covering <strong>Centralized Monitoring</strong>, <strong>Active Directory / OIDC Identity</strong>, <strong>Bastion Host</strong>, <strong>CAPI Lifecycle</strong>, and <strong>Air-Gapped Operations</strong> with Gemini 3.1 Flash TTS audio.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 flex-shrink-0 self-start sm:self-auto">
            <div className="text-right hidden sm:block">
              <div className="text-xs font-bold text-slate-800">
                Score: {correctCount}/{answeredCount > 0 ? answeredCount : 0}
              </div>
              <div className="text-[11px] text-slate-500">
                {answeredCount}/{NKP_QUESTIONS.length} Answered
              </div>
            </div>
            <button
              onClick={() => setActiveTab('architecture')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                activeTab === 'architecture'
                  ? 'bg-slate-900 text-white'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              Architecture Flow
            </button>
          </div>
        </div>

        {/* Tab 1: Primary Exam Questions */}
        {(activeTab === 'exam-question' || activeTab === 'practice-mode') && (
          <div className="space-y-6">
            {/* Question Selector Bar */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-white px-5 py-3.5 rounded-2xl border border-slate-200 gap-3 shadow-sm">
              <div className="flex items-center gap-2.5 flex-1 min-w-0">
                <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5 whitespace-nowrap">
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                  Question {questionIndex + 1} of {NKP_QUESTIONS.length}
                </span>
                
                {/* Question Dropdown Jump */}
                <select
                  value={questionIndex}
                  onChange={(e) => setQuestionIndex(Number(e.target.value))}
                  className="text-xs font-medium text-slate-800 bg-slate-50 hover:bg-slate-100 border border-slate-300 rounded-lg px-2.5 py-1.5 focus:outline-none focus:ring-2 focus:ring-emerald-500 max-w-xs md:max-w-md truncate"
                >
                  {NKP_QUESTIONS.map((q, idx) => {
                    const ans = userAnswers[q.id];
                    const statusText = ans?.isSubmitted
                      ? ans.selected === q.correctOptionId
                        ? '✓'
                        : '✗'
                      : '○';
                    return (
                      <option key={q.id} value={idx}>
                        {statusText} Q{idx + 1}: {q.title}
                      </option>
                    );
                  })}
                </select>
              </div>

              <div className="flex items-center gap-2 self-start sm:self-auto flex-shrink-0">
                <button
                  onClick={handlePrevQuestion}
                  disabled={questionIndex === 0}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors text-xs font-semibold flex items-center gap-1"
                  title="Previous Question"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Prev</span>
                </button>

                <div className="text-xs font-mono text-slate-600 px-1">
                  {questionIndex + 1} / {NKP_QUESTIONS.length}
                </div>

                <button
                  onClick={handleNextQuestion}
                  disabled={questionIndex === NKP_QUESTIONS.length - 1}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 text-white hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed transition-colors text-xs font-semibold flex items-center gap-1"
                  title="Next Question"
                >
                  <span>Next</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* The Question Card Component */}
            <QuestionCard
              question={currentQuestion}
              selectedOption={currentState.selected}
              onSelectOption={handleSelectOption}
              isSubmitted={currentState.isSubmitted}
              onSubmit={handleSubmit}
              onReset={handleReset}
            />

            {/* Automatic Deep Dive Reveal when submitted or button to jump */}
            {currentState.isSubmitted ? (
              <ExplanationDrawer question={currentQuestion} />
            ) : (
              <div className="bg-white rounded-2xl border border-slate-200 p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-slate-100 flex items-center justify-center text-slate-700">
                    <BookOpen className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-slate-900">Want to inspect the answer right away?</h4>
                    <p className="text-xs text-slate-500">
                      View the complete architectural breakdown and distractor analysis for Options A, B, C, and D.
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => {
                    handleSelectOption(currentQuestion.correctOptionId);
                    handleSubmit();
                  }}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-2 shadow-sm transition-colors whitespace-nowrap"
                >
                  <span>Reveal Correct Answer & Deep Dive</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Dedicated Deep Dive View */}
        {activeTab === 'deep-dive' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between bg-white px-5 py-3.5 rounded-2xl border border-slate-200 gap-3 shadow-sm">
              <div className="flex items-center gap-2.5 flex-1 min-w-0">
                <span className="text-xs font-bold text-slate-700 whitespace-nowrap">
                  Deep Dive Q{questionIndex + 1}:
                </span>
                <select
                  value={questionIndex}
                  onChange={(e) => setQuestionIndex(Number(e.target.value))}
                  className="text-xs font-medium text-slate-800 bg-slate-50 hover:bg-slate-100 border border-slate-300 rounded-lg px-2.5 py-1.5 focus:outline-none focus:ring-2 focus:ring-emerald-500 max-w-xs md:max-w-md truncate"
                >
                  {NKP_QUESTIONS.map((q, idx) => (
                    <option key={q.id} value={idx}>
                      Q{idx + 1}: {q.title}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <button
                  onClick={handlePrevQuestion}
                  disabled={questionIndex === 0}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors text-xs font-semibold"
                >
                  Prev
                </button>
                <span className="text-xs font-mono text-slate-500">
                  {questionIndex + 1} / {NKP_QUESTIONS.length}
                </span>
                <button
                  onClick={handleNextQuestion}
                  disabled={questionIndex === NKP_QUESTIONS.length - 1}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 text-white hover:bg-slate-800 disabled:opacity-40 disabled:cursor-not-allowed transition-colors text-xs font-semibold"
                >
                  Next
                </button>
              </div>
            </div>
            <ExplanationDrawer question={currentQuestion} />
          </div>
        )}

        {/* Tab 3: Architecture Topology View */}
        {activeTab === 'architecture' && (
          <div className="space-y-6">
            <ArchitectureDiagram />
          </div>
        )}

        {/* Tab 4: Prerequisites Checklist */}
        {activeTab === 'prerequisites' && (
          <div className="space-y-6">
            <PrerequisitesChecklist />
          </div>
        )}

        {/* Tab 5: Ask AI Assistant */}
        {activeTab === 'ask-ai' && (
          <div className="space-y-6">
            <AskAIAssistant />
          </div>
        )}

        {/* Tab 6: Windows Local Setup Guide */}
        {activeTab === 'local-setup' && (
          <div className="space-y-6">
            <LocalSetupGuide />
          </div>
        )}
      </main>

      {/* Floating / Sticky TTS Player Bar */}
      <AudioPlayerBar />
    </div>
  );
}
