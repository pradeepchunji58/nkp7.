import { Question } from '../../types';

export const batch2Questions: Question[] = [
  {
    id: 'nkp-q21',
    badge: 'Networking & Air-Gapped Cloud Provisioning',
    title: 'Customizing Pod CIDR in Air-Gapped AWS Deployments',
    scenario:
      'A Platform Engineer is deploying an NKP cluster within an air-gapped AWS environment. However, after an infrastructure planning session with the network team, it\'s been determined that the default CIDR block range that are used by pods on NKP clusters is already in use in their environment.',
    prompt: 'How can the engineer ensure there are no collisions between NKP pod traffic and the existing network using that subnet range?',
    options: [
      {
        id: 'a',
        text: '1. Create an NKP infrastructure provider for AWS in the NKP UI. 2. Select the Advanced Options button from the Network section of the Create Cluster page and specify a unique CIDR block range within the pod network field',
        isCorrect: false,
        explanation: 'In strict air-gapped deployments without internet reachability to AWS web endpoints, cloud provider creation through the UI is restricted compared to manifest-driven CLI.',
        nutanixEquivalent: 'UI Guided Network Configuration',
      },
      {
        id: 'b',
        text: '1. Create an NKP infrastructure provider for AWS in the NKP UI. 2. When deploying the NKP cluster through the UI, specify a unique CIDR block range for the pod network field in the Network section of the Create Cluster page.',
        isCorrect: false,
        explanation: 'Does not account for generating declarative air-gapped offline templates.',
        nutanixEquivalent: 'UI Workflow for Connected Environments',
      },
      {
        id: 'c',
        text: 'Because the environment is air-gapped, there will be no network traffic collision concerns and no adjustment needs to be made to the pod network CIDR block range.',
        isCorrect: false,
        explanation: 'Incorrect. Overlapping CIDRs will cause routing failures, asymmetric routing, and packet drops across internal subnets.',
        nutanixEquivalent: 'Ignored Subnet Collision',
      },
      {
        id: 'd',
        text: '1. Create the NKP cluster\'s manifest using the nkp create cluster command set and include the pod CIDR block range parameter when generating the cluster manifest. 2. Deploy the NKP cluster manifest.',
        isCorrect: true,
        explanation: 'Correct! The recommended GitOps/air-gapped procedure is to generate the declarative cluster manifest via `nkp create cluster aws --dry-run -o yaml --pod-cidr <range>` and then apply that manifest cleanly.',
        nutanixEquivalent: 'Declarative Manifest Generation via CLI (--pod-cidr)',
      },
    ],
    correctOptionId: 'd',
    keyTakeaway: 'In air-gapped environments, generate the cluster manifest via the NKP CLI specifying the non-conflicting pod CIDR parameter, review the YAML, and deploy the manifest.',
    deepExplanation: `Pod Network Customization:
- NKP defaults to standard pod subnets (e.g. 192.168.0.0/16 or Calico defaults).
- When enterprise VPCs or transit gateways overlap with this range, generate the cluster definition offline using \`--pod-cidr <custom-cidr>\`.
- Deploying the validated manifest ensures CNI controllers and kube-proxy configure IPAM and iptables/eBPF routing tables cleanly without collisions.`,
  },
  {
    id: 'nkp-q22',
    badge: 'Air-Gapped Bastion Architecture',
    title: 'Increased Storage Requirements on Air-Gapped Bastion VM',
    scenario: 'What causes an air-gapped bastion VM to have increased storage requirements?',
    prompt: 'What causes an air-gapped bastion VM to have increased storage requirements?',
    options: [
      {
        id: 'a',
        text: 'The cluster etcd datastore and control-plane certificates',
        isCorrect: false,
        explanation: 'Etcd data and certificates reside on control plane nodes, consuming negligible disk space on the bastion.',
        nutanixEquivalent: 'Control Plane Datastore',
      },
      {
        id: 'b',
        text: 'The workload pods\' persistent volumes and CSI data',
        isCorrect: false,
        explanation: 'Workload PVC data resides in the Nutanix cluster storage containers, never on the bastion VM.',
        nutanixEquivalent: 'Workload Persistent Storage',
      },
      {
        id: 'c',
        text: 'The Kommander management components and dashboard',
        isCorrect: false,
        explanation: 'Kommander runs inside the management cluster as pods, not on the bastion host filesystem.',
        nutanixEquivalent: 'Kommander Control Plane Pods',
      },
      {
        id: 'd',
        text: 'The Konvoy air-gapped bundles and the local image registry',
        isCorrect: true,
        explanation: 'Correct! In an air-gapped deployment, the bastion VM must store multiple gigabytes of container image tarballs (Konvoy and Kommander darksite bundles) and host or seed the local container registry (e.g., Harbor or Docker distribution registry).',
        nutanixEquivalent: 'NKP Darksite Bundles & Local Container Registry Storage',
      },
    ],
    correctOptionId: 'd',
    keyTakeaway: 'Air-gapped bastions require significantly increased disk storage (typically 200–500 GB) to hold the multi-gigabyte NKP darksite image bundles and run the local container registry.',
    deepExplanation: `Air-Gapped Bastion Storage Demands:
1. **Konvoy Bundle**: Contains all base Kubernetes, CNI, CSI, and CAPI container image layers.
2. **Kommander Bundle**: Contains platform applications (monitoring, logging, service mesh, dashboards).
3. **Local Container Registry**: Often hosted directly on the bastion or a dedicated jump VM to serve images to internal nodes without internet connectivity.`,
  },
  {
    id: 'nkp-q23',
    badge: 'Kommander Installation & CLI',
    title: 'Installing Kommander Using an Installer Configuration File',
    scenario:
      'An administrator created the initial Kommander installer configuration file and is now installing the Kommander.',
    prompt: 'Which option can be used to create the Kommander with the installer configuration file?',
    options: [
      {
        id: 'a',
        text: 'nkp create kornmander -f kornmander.yaml kubeconfig=${CLUSTER_NAME}.conf',
        isCorrect: false,
        explanation: 'The command is `install kommander`, not `create kommander`.',
        nutanixEquivalent: 'Invalid Verb Syntax',
      },
      {
        id: 'b',
        text: 'nkp install kommander --installer-config kommander.yaml --kubeconfig=${CLUSTER_NAME}.conf',
        isCorrect: true,
        explanation: 'Correct! The official NKP CLI syntax is `nkp install kommander --installer-config kommander.yaml --kubeconfig=${CLUSTER_NAME}.conf`.',
        nutanixEquivalent: 'Official NKP CLI: nkp install kommander --installer-config',
      },
      {
        id: 'c',
        text: 'nkp install kornmander -f kornmander.yaml kubeconfig=${CLUSTER_NAME}.conf',
        isCorrect: false,
        explanation: 'Missing double dashes on `--kubeconfig` and uses invalid `-f` flag instead of `--installer-config`.',
        nutanixEquivalent: 'Malformed Flag Syntax',
      },
      {
        id: 'd',
        text: 'nkp create kornmander --installer-config kornmander.yaml --kubeconfig=${CLUSTER_NAME}.conf',
        isCorrect: false,
        explanation: 'The NKP CLI command verb is `install kommander`, not `create kommander`.',
        nutanixEquivalent: 'Incorrect Command Verb',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'Use `nkp install kommander --installer-config <config.yaml> --kubeconfig=<kubeconfig>` to deploy Kommander with customized installer parameters.',
    deepExplanation: `Kommander Installation Workflow:
- Step 1: Generate the configuration file with \`nkp install kommander --init > kommander.yaml\`.
- Step 2: Edit platform application overrides, ingress settings, and storage classes.
- Step 3: Execute installation with \`nkp install kommander --installer-config kommander.yaml --kubeconfig=\${CLUSTER_NAME}.conf\`.`,
  },
  {
    id: 'nkp-q24',
    badge: 'Platform Applications & AppDeployment',
    title: 'Enabling an Application via the NKP CLI',
    scenario:
      'An admin is enabling app kiali.2.18 using the NKP CLI.',
    prompt: 'Which command correctly identifies the <App-ID> and <Version>?',
    options: [
      {
        id: 'a',
        text: 'nkp create appdeployment kiali --app kiali-2.18. --workspace ${WORKSPACE_NAME}',
        isCorrect: true,
        explanation: 'Correct! In NKP, application deployment resources are created using `nkp create appdeployment <deployment-name> --app <app-id>-<version> --workspace <workspace-name>`.',
        nutanixEquivalent: 'nkp create appdeployment --app <app>-<version> --workspace',
      },
      {
        id: 'b',
        text: 'nkp apply appdeployment kiali --enbl kiali-2.18.--workspace ${WORKSPACE_NAME}',
        isCorrect: false,
        explanation: '`apply` and `--enbl` are not valid NKP CLI commands or flags.',
        nutanixEquivalent: 'Invalid Flag --enbl',
      },
      {
        id: 'c',
        text: 'nkp create appdeployment kiali --enbl kiali.2.18.--workspace${WORKSPACE_NAME}',
        isCorrect: false,
        explanation: 'The flag is `--app`, not `--enbl`, and app IDs use hyphens between name and version.',
        nutanixEquivalent: 'Incorrect Flag Syntax',
      },
      {
        id: 'd',
        text: 'nkp run appdeployment kiali --app kiali.2.18.--workspace ${WORKSPACE_NAME}',
        isCorrect: false,
        explanation: '`run` is not the sub-command for creating AppDeployments in NKP CLI.',
        nutanixEquivalent: 'Invalid Sub-command',
      },
    ],
    correctOptionId: 'a',
    keyTakeaway: 'The command syntax `nkp create appdeployment <name> --app <catalog-app-id-version> --workspace <workspace>` declaratively deploys a platform application.',
    deepExplanation: `AppDeployment Resource Model:
- Kommander maintains a catalog of verified platform applications (Traefik, Prometheus, Kiali, Gatekeeper).
- Each catalog entry is identified by an ID and version string (e.g. \`kiali-2.18.x\`).
- Running \`nkp create appdeployment\` instantiates an \`AppDeployment\` custom resource inside the workspace namespace, triggering Flux to deploy the Helm release.`,
  },
  {
    id: 'nkp-q25',
    badge: 'Centralized Metrics & Observability',
    title: 'Centralized Cross-Cluster Metric Collection and Troubleshooting',
    scenario:
      'Recently, the reliability of some developer platforms have been impacted by out-of-memory errors, causing pods to crash and then remain in a pending state. A Cloud Engineer has been tasked with collecting and reviewing centralized metrics across the various platform environments to identify differences between them and better understand what is causing these performance issues.',
    prompt: 'What should the engineer do to address this request?',
    options: [
      {
        id: 'a',
        text: 'Utilize Fluentd and Fluent Bit to collect and present centralized metrics on NKP attached and managed clusters. Visualize these collected and centralized metrics in Grafana.',
        isCorrect: false,
        explanation: 'Fluentd and Fluent Bit are logging log-shippers, not time-series metrics collectors.',
        nutanixEquivalent: 'Log Shippers (Fluent Bit/Fluentd)',
      },
      {
        id: 'b',
        text: 'Utilize Prometheus to collect and present centralized metrics on NKP attached and managed clusters. Configure Thanos Query to monitor and send out alerts based on the metric thresholds that have been configured within it.',
        isCorrect: false,
        explanation: 'Thanos Query is a query engine for visualization, while Alertmanager handles alerting.',
        nutanixEquivalent: 'Thanos Query Alerting Misattribution',
      },
      {
        id: 'c',
        text: 'Utilize Fluentd and Fluent Bit to collect and present centralized metrics on NKP attached and managed clusters. Configure Thanos Query to monitor and send out alerts based on the metric thresholds that have been configured within it.',
        isCorrect: false,
        explanation: 'Fluent Bit is for logs, not metric aggregation.',
        nutanixEquivalent: 'Logging Pipeline',
      },
      {
        id: 'd',
        text: 'Utilize Thanos to collect and present centralized metrics on NKP attached and managed clusters. Visualize these collected and centralized metrics in Grafana.',
        isCorrect: true,
        explanation: 'Correct! Thanos provides global query aggregation across multiple Prometheus instances on attached and managed clusters, presenting a unified time-series dataset visualized in centralized Grafana dashboards.',
        nutanixEquivalent: 'Thanos Multi-Cluster Metrics Federation & Grafana',
      },
    ],
    correctOptionId: 'd',
    keyTakeaway: 'Thanos aggregates metrics across all attached and managed clusters into a single centralized query view, visualized seamlessly through Grafana in Kommander.',
    deepExplanation: `Observability Architecture:
- Each cluster runs local Prometheus and Thanos Sidecar.
- The management cluster runs Thanos Querier, which federates queries across all Thanos Sidecars and Thanos Store gateways.
- Grafana connects to Thanos Querier as its default Prometheus data source, allowing SREs to compare memory, CPU, and node trends across all clusters side-by-side.`,
  },
  {
    id: 'nkp-q26',
    badge: 'Bootstrap Networking & Pre-flight',
    title: 'Resolving Default Bootstrap Subnet Conflict (172.18.0.0/16)',
    scenario:
      'A company network already uses 172.18.0.0/16, which is the NKP bootstrap default. However, the administrator has not yet run the nkp create bootstrap command.',
    prompt: 'What is the correct action?',
    options: [
      {
        id: 'a',
        text: 'Edit /etc/cloud/cloud.cfg.d/ on the operator machine.',
        isCorrect: false,
        explanation: 'Cloud-init configurations on the operator machine do not govern the Docker bridge subnet created by Kind.',
        nutanixEquivalent: 'Cloud-init Configuration',
      },
      {
        id: 'b',
        text: 'Change the company\'s network off 172.18.0.0/16.',
        isCorrect: false,
        explanation: 'Renumbering an entire enterprise corporate network is impractical and unnecessary.',
        nutanixEquivalent: 'Corporate Network Renumbering',
      },
      {
        id: 'c',
        text: 'Export a non-conflicting subnet and gateway.',
        isCorrect: true,
        explanation: 'Correct! Before running `nkp create bootstrap`, you can override Kind\'s default Docker bridge subnet (172.18.0.0/16) by exporting the environment variable `KIND_EXPERIMENTAL_DOCKER_NETWORK` or setting the custom subnet flag to a non-conflicting IP range.',
        nutanixEquivalent: 'Export Non-Conflicting KIND Docker Subnet',
      },
      {
        id: 'd',
        text: 'Run nkp create bootstrap first, then renumber the subnet afterward.',
        isCorrect: false,
        explanation: 'Once created, Docker bridge networks cannot be renumbered without tearing down the bootstrap cluster.',
        nutanixEquivalent: 'Post-Creation Bridge Renumbering',
      },
    ],
    correctOptionId: 'c',
    keyTakeaway: 'To prevent IP collisions with Kind\'s default 172.18.0.0/16 bridge network, export a non-conflicting subnet and gateway before creating the bootstrap cluster.',
    deepExplanation: `Kind Subnet Customization:
- Kind by default creates a Docker bridge network with IP range \`172.18.0.0/16\`.
- If the bastion host or corporate intranet uses this subnet, routing loops and packet loss will occur.
- Setting \`export KIND_EXPERIMENTAL_DOCKER_NETWORK=10.240.0.0/16\` before invoking \`nkp create bootstrap\` forces Docker to create the bridge on an uncontested subnet.`,
  },
  {
    id: 'nkp-q27',
    badge: 'Nutanix AHV Stretched Clustering & Latency',
    title: 'Maximum Network Round Trip Latency Between Control Planes',
    scenario:
      'When deploying the NKP on Nutanix Infrastructure and leveraging failure domains, what is the maximum Network round trip latency between control planes?',
    prompt: 'What is the maximum Network round trip latency between control planes?',
    options: [
      {
        id: 'a',
        text: '5 ms',
        isCorrect: false,
        explanation: '5 ms is ideal for Metro Availability, but the supported ceiling for etcd consensus across failure domains is 10 ms.',
        nutanixEquivalent: 'Metro Replication Latency',
      },
      {
        id: 'b',
        text: '10 ms',
        isCorrect: true,
        explanation: 'Correct! Nutanix Kubernetes Platform and etcd distributed consensus require a maximum network round-trip time (RTT) latency of 10 ms between control plane nodes across failure domains to prevent election timeouts and split-brain states.',
        nutanixEquivalent: '10 ms Maximum RTT for Control Plane / etcd Consensus',
      },
      {
        id: 'c',
        text: '15 ms',
        isCorrect: false,
        explanation: '15 ms exceeds the safe threshold for etcd heartbeats and leaderelections under standard tuning.',
        nutanixEquivalent: 'High Latency Risk',
      },
      {
        id: 'd',
        text: '100 ms',
        isCorrect: false,
        explanation: '100 ms will cause severe etcd leader election instability and control plane partition failure.',
        nutanixEquivalent: 'WAN Latency',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'The maximum supported network round-trip latency between control plane nodes across failure domains is 10 ms to maintain etcd raft stability.',
    deepExplanation: `Etcd Consensus Across Failure Domains:
- In multi-rack or campus failure domain architectures on Nutanix AHV, control plane nodes are distributed across clusters.
- Because etcd relies on Raft consensus, write latency is dictated by the slowest node quorum.
- Maintaining < 10 ms RTT prevents heartbeats from dropping and avoids leader election churn.`,
  },
  {
    id: 'nkp-q28',
    badge: 'Workspace Application Automation',
    title: 'Deploying Logging Stack Components Automatically to Workload Clusters',
    scenario:
      'A Kubernetes administrator needs to ensure that the following requirements are met whenever a new workload cluster is deployed to a workspace: 1. Grafana Logging 2. Grafana Loki 3. Project Logging',
    prompt: 'How would the administrator ensure that these components are deployed as part of a cluster deployment?',
    options: [
      {
        id: 'a',
        text: 'Enable them in the Insights section under workspace.',
        isCorrect: false,
        explanation: 'Insights provides automated cluster diagnostics and anomaly detection, not logging pipeline management.',
        nutanixEquivalent: 'NKP Insights Dashboard',
      },
      {
        id: 'b',
        text: 'Enable them in the Application section under workspace.',
        isCorrect: true,
        explanation: 'Correct! Enabling platform applications in the Applications section of the Workspace automatically deploys those applications to any cluster currently in or subsequently added to that workspace.',
        nutanixEquivalent: 'Workspace Applications Dashboard (AppDeployments)',
      },
      {
        id: 'c',
        text: 'Enable them in the Projects section under workspace.',
        isCorrect: false,
        explanation: 'Projects define developer namespace boundaries, not cluster-wide platform infrastructure.',
        nutanixEquivalent: 'Projects Section',
      },
      {
        id: 'd',
        text: 'Enable them in the Clusters section under workspace.',
        isCorrect: false,
        explanation: 'The Clusters section manages cluster lifecycle and attachment, not declarative application catalogs.',
        nutanixEquivalent: 'Clusters Section',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'Enabling platform applications in the Workspace Applications catalog ensures they are automatically deployed to all current and future workload clusters in that workspace.',
    deepExplanation: `Workspace Application Inheritance:
- Kommander uses declarative GitOps inheritance.
- When an application (e.g. Loki, Grafana Logging) is enabled under **Workspace > Applications**, an \`AppDeployment\` is created in the workspace namespace.
- Any cluster attached to the workspace inherits and installs the application automatically.`,
  },
  {
    id: 'nkp-q29',
    badge: 'Air-Gapped Bastion Setup',
    title: 'First Step to Configure Rocky Linux Bastion Host for Air-Gapped Cluster',
    scenario:
      'A Platform Engineer has been tasked with setting up an NKP cluster in an air-gapped environment using a bastion host. The cluster nodes will not have access to the Internet, and the engineer will need to ensure that container images will still be able to be pulled from a registry. The bastion host is currently set up with Rocky Linux and the engineer will need to configure it to meet the requirements for the air-gapped cluster.',
    prompt: 'Which first step should the engineer take to configure the bastion host?',
    options: [
      {
        id: 'a',
        text: 'Set up a connection on the bastion host so that it can pull images from Docker Hub.',
        isCorrect: false,
        explanation: 'In a true air-gapped security model, the production bastion has no direct internet connection to Docker Hub.',
        nutanixEquivalent: 'Direct Internet Access',
      },
      {
        id: 'b',
        text: 'Create a bootstrap cluster.',
        isCorrect: false,
        explanation: 'You cannot create a bootstrap cluster until container tools and OS utilities are installed.',
        nutanixEquivalent: 'Bootstrap Creation',
      },
      {
        id: 'c',
        text: 'Install the pre-requisites: yum-utils, bzip2, and wget.',
        isCorrect: true,
        explanation: 'Correct! Step 1 of the official Nutanix documentation for preparing an enterprise Linux (RHEL/Rocky Linux) bastion host is installing the required OS utility packages: yum-utils, bzip2, and wget.',
        nutanixEquivalent: 'Bastion OS Tooling Prerequisites (yum-utils, bzip2, wget)',
      },
      {
        id: 'd',
        text: 'Configure the bastion VM with a public IP address.',
        isCorrect: false,
        explanation: 'Air-gapped architectures strictly prohibit public IP addresses on bastion VMs.',
        nutanixEquivalent: 'Public IP Violation',
      },
    ],
    correctOptionId: 'c',
    keyTakeaway: 'The first step on a Rocky Linux/RHEL bastion host is installing baseline OS prerequisites: yum-utils, bzip2, and wget to unpack and manage NKP bundles.',
    deepExplanation: `Official Rocky Linux Bastion Preparation:
1. Install base utilities: \`sudo dnf install -y yum-utils bzip2 wget curl tar\`.
2. Configure Docker/containerd repository and install container engine.
3. Download or transfer the NKP binary and air-gapped tarball bundles.
4. Extract the NKP CLI to \`/usr/local/bin\`.`,
  },
  {
    id: 'nkp-q30',
    badge: 'Cluster Monitoring & Alerting',
    title: 'Default Stack for Metrics, Alerting, and Dashboards in NKP',
    scenario:
      'A newly-created NKP cluster needs metric collection, alerting, and visualization working from the start. The cluster is using the default NKP monitoring components.',
    prompt: 'Which stack fills that role?',
    options: [
      {
        id: 'a',
        text: 'Kubernetes Dashboard',
        isCorrect: false,
        explanation: 'Kubernetes Dashboard is a basic web UI and does not include a time-series metric engine or alert manager.',
        nutanixEquivalent: 'Kubernetes Dashboard',
      },
      {
        id: 'b',
        text: 'Grafana Loki stack',
        isCorrect: false,
        explanation: 'Loki is a log aggregation engine, not a time-series metric and alert evaluation stack.',
        nutanixEquivalent: 'Loki Log Aggregator',
      },
      {
        id: 'c',
        text: 'Thanos deployment',
        isCorrect: false,
        explanation: 'Thanos federates multi-cluster metrics, but the local collection, alert evaluation, and scrape targets are driven by the Prometheus stack.',
        nutanixEquivalent: 'Thanos Metric Store',
      },
      {
        id: 'd',
        text: 'Prometheus stack',
        isCorrect: true,
        explanation: 'Correct! The default monitoring stack deployed in NKP clusters is the Prometheus stack (kube-prometheus-stack), which includes Prometheus for scraping metrics, Alertmanager for alerting, and node-exporter/kube-state-metrics.',
        nutanixEquivalent: 'kube-prometheus-stack (Prometheus, Alertmanager, Node Exporter)',
      },
    ],
    correctOptionId: 'd',
    keyTakeaway: 'The Prometheus stack (kube-prometheus-stack) is the default, out-of-the-box engine providing metric collection, alerting rules, and node metrics in NKP.',
    deepExplanation: `Default Monitoring Architecture:
- Built on Prometheus Operator.
- Deploys \`ServiceMonitor\` and \`PodMonitor\` CRDs to automatically discover cluster targets.
- Pre-configured with Nutanix/Kubernetes alerts for node CPU/memory pressure, disk saturation, and pod restart loops.`,
  },
  {
    id: 'nkp-q31',
    badge: 'Platform Applications & Registry',
    title: 'Retrieving Harbor Admin Password in NKP Management Cluster',
    scenario:
      'An administrator successfully deployed Harbor in the NKP Management cluster but is unaware of the password to log in to the Harbor GUI.',
    prompt: 'Which parameter must be used in the following command? (Fill in the blank.)',
    options: [
      {
        id: 'a',
        text: 'kube-system',
        isCorrect: false,
        explanation: 'Platform application secrets are never stored in kube-system.',
        nutanixEquivalent: 'kube-system Namespace',
      },
      {
        id: 'b',
        text: 'harbor',
        isCorrect: false,
        explanation: 'In Kommander-managed deployments, platform application credentials and charts are maintained within the kommander namespace.',
        nutanixEquivalent: 'Application-specific Namespace',
      },
      {
        id: 'c',
        text: 'kommander',
        isCorrect: true,
        explanation: 'Correct! In NKP, management cluster platform applications and their generated administrator secret objects are housed in the kommander namespace (`kubectl get secret -n kommander harbor-admin-password`).',
        nutanixEquivalent: 'kommander Namespace',
      },
      {
        id: 'd',
        text: 'ncr-system',
        isCorrect: false,
        explanation: '`ncr-system` is not the standard namespace used by Kommander for Harbor secrets.',
        nutanixEquivalent: 'NCR Namespace',
      },
    ],
    correctOptionId: 'c',
    keyTakeaway: 'Harbor administrative credentials and platform application secrets on the management cluster are stored in the `kommander` namespace.',
    deepExplanation: `Retrieving Harbor Password:
- Command: \`kubectl get secret -n kommander harbor-admin-password -o jsonpath='{.data.password}' | base64 --decode\`
- Kommander centralizes all management application secrets inside the \`kommander\` namespace for security auditing and lifecycle tracking.`,
  },
  {
    id: 'nkp-q32',
    badge: 'Air-Gapped Private Registry Management',
    title: 'CLI Options to Push NKP Bundle to Private Registry',
    scenario:
      'A company uses an Artifactory private registry for development. The NKP deployment must use this private registry since the Security Administrator has the firewall configured to reject connections to public container registries. The first task is to push the NKP bundle to this private registry.',
    prompt: 'What options should be used to push NKP bundle to this private registry?',
    options: [
      {
        id: 'a',
        text: '--registry-mirror-url, --registry-mirror-username and --registry-mirror-password',
        isCorrect: false,
        explanation: 'Mirror flags configure node pull redirection, not bundle push targets.',
        nutanixEquivalent: 'Mirror Flags',
      },
      {
        id: 'b',
        text: '--to-registry, --to-registry-username and --to-registry-password',
        isCorrect: true,
        explanation: 'Correct! The `nkp push bundle` command uses `--to-registry`, `--to-registry-username`, and `--to-registry-password` to specify the destination registry where bundle container images are pushed.',
        nutanixEquivalent: 'nkp push bundle --to-registry --to-registry-username --to-registry-password',
      },
      {
        id: 'c',
        text: '--registry-url, --registry-username and --registry-password',
        isCorrect: false,
        explanation: 'These are generic descriptors rather than the exact CLI arguments recognized by the push command.',
        nutanixEquivalent: 'Generic Registry Flags',
      },
      {
        id: 'd',
        text: '--mirror-url, --mirror-username and --mirror-password',
        isCorrect: false,
        explanation: 'Not the flags recognized by `nkp push bundle`.',
        nutanixEquivalent: 'Mirror Flags',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'The `nkp push bundle` command uses `--to-registry`, `--to-registry-username`, and `--to-registry-password` to push container image bundles to private registries.',
    deepExplanation: `Pushing Bundles to Private Registry:
- Command:
  \`nkp push bundle --bundle ./konvoy-image-bundle-v2.x.tar.gz --to-registry artifactory.corp.local:5000/nkp --to-registry-username admin --to-registry-password <secret>\`
- Unpacks image layers and retags them to match the internal enterprise registry hierarchy.`,
  },
  {
    id: 'nkp-q33',
    badge: 'Kommander RBAC & Governance',
    title: 'Resource Group for Creating Cluster Roles on Management Cluster',
    scenario: 'NKP UI has two conceptual resource groups to manage access control.',
    prompt: 'Which resource group allows for creating cluster roles on the management cluster?',
    options: [
      {
        id: 'a',
        text: 'Workspace Role',
        isCorrect: false,
        explanation: 'Workspace Roles are scoped exclusively within individual workspaces and their member clusters.',
        nutanixEquivalent: 'Workspace Role',
      },
      {
        id: 'b',
        text: 'Global Role',
        isCorrect: true,
        explanation: 'Correct! In Kommander, Global Roles define permissions applied across the entire management cluster and all workspaces, enabling administrative control at the highest organizational level.',
        nutanixEquivalent: 'Global Role (Management Cluster Scope)',
      },
      {
        id: 'c',
        text: 'Cluster Role',
        isCorrect: false,
        explanation: 'ClusterRole is standard vanilla Kubernetes RBAC, not the specific Kommander UI resource grouping construct.',
        nutanixEquivalent: 'Kubernetes ClusterRole',
      },
      {
        id: 'd',
        text: 'Kommander Role',
        isCorrect: false,
        explanation: '`Kommander Role` is not the conceptual resource group name in the UI.',
        nutanixEquivalent: 'Invalid Resource Term',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'Global Roles in Kommander grant cross-workspace and management cluster-wide privileges, unlike Workspace Roles which are bounded to a single workspace.',
    deepExplanation: `Kommander RBAC Conceptual Model:
- **Global Roles**: Mapped across all workspaces and the management cluster (e.g., Global Admin, Global Viewer).
- **Workspace Roles**: Mapped within a single workspace to govern tenant clusters and project namespaces (e.g., Workspace Admin, Workspace Contributor).`,
  },
  {
    id: 'nkp-q34',
    badge: 'Bootstrap Lifecycle',
    title: 'Cleaning Up a Bootstrap Cluster with self-managed=false',
    scenario:
      'An NKP administrator creates a new bootstrap cluster for NKP deployment using the default self-managed=false setting.',
    prompt: 'Which command will clean up the bootstrap cluster?',
    options: [
      {
        id: 'a',
        text: 'docker rm -a',
        isCorrect: false,
        explanation: 'Destroys all Docker containers on the host, which is destructive to other services and ungraceful.',
        nutanixEquivalent: 'Destructive Docker Purge',
      },
      {
        id: 'b',
        text: 'docker rm konvoy',
        isCorrect: false,
        explanation: 'Kind clusters are named specifically after the cluster generation context, not simply "konvoy".',
        nutanixEquivalent: 'Invalid Container Target',
      },
      {
        id: 'c',
        text: 'kubectl delete bootstrap',
        isCorrect: false,
        explanation: 'There is no native Kubernetes API resource named "bootstrap".',
        nutanixEquivalent: 'Non-existent K8s Object',
      },
      {
        id: 'd',
        text: 'nkp delete bootstrap',
        isCorrect: true,
        explanation: 'Correct! The dedicated command `nkp delete bootstrap` safely and completely terminates the Kind container and cleans up temporary local files and networks on the bastion host.',
        nutanixEquivalent: 'nkp delete bootstrap',
      },
    ],
    correctOptionId: 'd',
    keyTakeaway: 'Use `nkp delete bootstrap` to cleanly tear down the temporary Kind bootstrap cluster after provisioning is complete.',
    deepExplanation: `Bootstrap Teardown:
- When a deployment finishes, the bootstrap cluster is no longer needed.
- \`nkp delete bootstrap\` deletes the Kind cluster container, releases loopback network bridges, and removes temporary kubeconfig references.`,
  },
  {
    id: 'nkp-q35',
    badge: 'Secure Tunnel & Firewall Configuration',
    title: 'Firewall Port Requirement for NKP Secure Tunnel',
    scenario:
      'A Platform Engineer is attaching existing Kubernetes clusters to NKP, but some of them have network restrictions, so there is a need to use Secure Tunnel. The Platform Engineer needs to ask the Security Engineer to modify the firewall rules.',
    prompt: 'What must the firewall rules allow on the attached cluster network?',
    options: [
      {
        id: 'a',
        text: 'iSCSI (TCP/86 & 3260)',
        isCorrect: false,
        explanation: 'iSCSI is for block storage communication, not multi-cluster management tunnels.',
        nutanixEquivalent: 'Storage Fabric Protocol',
      },
      {
        id: 'b',
        text: 'NTP Service (UDP/123)',
        isCorrect: false,
        explanation: 'NTP provides clock synchronization, not API tunnel proxying.',
        nutanixEquivalent: 'Clock Synchronization',
      },
      {
        id: 'c',
        text: 'HTTPS (TCP/443)',
        isCorrect: true,
        explanation: 'Correct! NKP Secure Tunnel (kubetunnel) requires only outbound HTTPS (TCP/443) from the attached cluster to the management cluster load balancer/ingress.',
        nutanixEquivalent: 'HTTPS (TCP/443) Outbound Secure Tunnel',
      },
      {
        id: 'd',
        text: 'Secured LDAP (TCP/636)',
        isCorrect: false,
        explanation: 'LDAPS connects Dex to directory servers, not attached clusters to the management plane.',
        nutanixEquivalent: 'Directory Service Protocol',
      },
    ],
    correctOptionId: 'c',
    keyTakeaway: 'NKP Secure Tunnel requires only outbound TCP port 443 (HTTPS) from the attached cluster to the management cluster, avoiding complex inbound firewall rules.',
    deepExplanation: `Secure Tunnel Networking:
- Client agent running on attached cluster dials outbound to Kommander on port 443.
- Upgrades connection to an encrypted multiplexed websocket/TLS tunnel.
- Kommander pushes configurations and queries metrics reverse-tunneled over this secure channel.`,
  },
  {
    id: 'nkp-q36',
    badge: 'Identity Federation & Authentication',
    title: 'Setting Up User Authentication in NKP',
    scenario: 'A Platform Engineer is setting up user authentication into an NKP cluster.',
    prompt: 'How should the engineer accomplish this task?',
    options: [
      {
        id: 'a',
        text: 'Enable Gatekeeper and create a connector to the user base\'s identity provider.',
        isCorrect: false,
        explanation: 'Gatekeeper is an admission policy controller (OPA), not an identity provider or SSO broker.',
        nutanixEquivalent: 'OPA Gatekeeper Policy Controller',
      },
      {
        id: 'b',
        text: 'Create a Dex connector to the user base\'s identity provider.',
        isCorrect: true,
        explanation: 'Correct! Dex is the federated OpenID Connect (OIDC) identity provider bundled in NKP. To integrate with enterprise directories (Active Directory, LDAP, Okta, SAML, GitHub), you configure a Dex connector.',
        nutanixEquivalent: 'Dex Identity Connector (LDAP, SAML, OIDC)',
      },
      {
        id: 'c',
        text: 'Disable native NKP authentication, enable Traefik, and create a connector to the user base\'s identity provider.',
        isCorrect: false,
        explanation: 'Traefik is an ingress proxy and does not handle user directory synchronization or token issuance.',
        nutanixEquivalent: 'Traefik Ingress Proxy',
      },
      {
        id: 'd',
        text: 'Create a MetalLB connector to the user base\'s identity provider.',
        isCorrect: false,
        explanation: 'MetalLB is a layer-2 load balancer implementation, having zero relation to identity management.',
        nutanixEquivalent: 'MetalLB Load Balancer',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'User authentication in NKP is configured by creating a Dex connector to the organization\'s identity provider (e.g. LDAP, SAML, or OIDC).',
    deepExplanation: `Dex Identity Broker in NKP:
- Acts as a mediator between external IdPs and the Kubernetes API / Kommander UI.
- Translates LDAP/AD groups into standard JWT/OIDC claims.
- Supported connectors: \`ldap\`, \`saml\`, \`oidc\`, \`github\`, \`gitlab\`.`,
  },
  {
    id: 'nkp-q37',
    badge: 'Multi-Tenancy & Tenant Administrators',
    title: 'Assigning Tenant Administrators for Workspaces with Distinct IdPs',
    scenario:
      'A Platform Engineer is a member of an IT team that provides Kubernetes clusters for three groups within a company named Fin Group, Inc. (Fin VD, Fin Insurance, Fin Travel). The engineer created workspaces for every group. Fin Group Inc. has its own Active Directory implementation, while each group uses their own Identity Provider. Now, the engineer needs to assign the Tenant Administrators for each workspace.',
    prompt: 'How will the engineer complete this task?',
    options: [
      {
        id: 'a',
        text: 'Configure the global Active Directory and assign a workspace admin user to each group.',
        isCorrect: false,
        explanation: 'Does not accommodate the distinct identity providers utilized by each separate division.',
        nutanixEquivalent: 'Centralized IdP Assumption',
      },
      {
        id: 'b',
        text: 'Create a role named admin-tenant-X, where X is the name of the group and assign that role to manage the corresponding workspace.',
        isCorrect: false,
        explanation: 'Custom role names are unnecessary; the built-in `workspace-admin` role already contains all required permissions.',
        nutanixEquivalent: 'Redundant Custom Roles',
      },
      {
        id: 'c',
        text: 'Create a role binding and assign it to manage the corresponding workspace.',
        isCorrect: true,
        explanation: 'Correct! To grant tenant administration in Kommander, you create a WorkspaceRoleBinding within each workspace, binding the group/user from the respective Identity Provider to the workspace-admin role.',
        nutanixEquivalent: 'WorkspaceRoleBinding to workspace-admin Role',
      },
      {
        id: 'd',
        text: 'Configure a dedicated identity provider for each group to access their own workspace.',
        isCorrect: false,
        explanation: 'IdPs authenticate users, but assigning management rights requires creating the RoleBinding.',
        nutanixEquivalent: 'IdP Configuration Alone',
      },
    ],
    correctOptionId: 'c',
    keyTakeaway: 'Tenant administration is granted by creating a WorkspaceRoleBinding within each workspace binding the designated IdP subjects to the workspace-admin role.',
    deepExplanation: `Tenant Workspace Administration:
- Each workspace has a dedicated namespace in the management cluster.
- A \`WorkspaceRoleBinding\` inside that namespace references the \`workspace-admin\` ClusterRole and binds it to the tenant's group claim (e.g. \`oidc:Fin-Travel-Admins\`).
- This restricts administrative powers strictly to that workspace's clusters and applications.`,
  },
  {
    id: 'nkp-q38',
    badge: 'Workspace Role Bindings Syntax',
    title: 'Syntax for Identity Provider Groups in Workspace Role Bindings',
    scenario:
      'A workspace group has been configured for a specific workspace. An administrator would like to configure Workspace Role Bindings for Identity Provider Groups.',
    prompt: 'What is the correct syntax used to add them to the workspace?',
    options: [
      {
        id: 'a',
        text: 'oidc:<workspace_name>:<IdP_user_group>',
        isCorrect: false,
        explanation: 'The workspace name is not part of the Dex claim subject string.',
        nutanixEquivalent: 'Malformed Subject Format',
      },
      {
        id: 'b',
        text: '<workspace_ID>:<user_email>',
        isCorrect: false,
        explanation: 'This does not target an IdP group and includes invalid workspace ID prefixes.',
        nutanixEquivalent: 'User Email Format',
      },
      {
        id: 'c',
        text: '<user_email>',
        isCorrect: false,
        explanation: 'Targets an individual user rather than an external Identity Provider group.',
        nutanixEquivalent: 'Individual User Subject',
      },
      {
        id: 'd',
        text: 'oidc:<IdP_user_group>',
        isCorrect: true,
        explanation: 'Correct! In Kommander, external identity provider groups forwarded by Dex are prefixed with `oidc:` (e.g. `oidc:devops-engineers`) when mapped as subjects in RoleBindings.',
        nutanixEquivalent: 'oidc:<IdP_user_group> Subject Syntax',
      },
    ],
    correctOptionId: 'd',
    keyTakeaway: 'The correct syntax to bind an Identity Provider group in NKP/Kommander role bindings is `oidc:<IdP_user_group>`.',
    deepExplanation: `Dex Group Claim Subject Syntax:
- Dex appends \`oidc:\` to all group claims in the JWT token.
- When creating a \`WorkspaceRoleBinding\`, the \`subjects\` field must be:
  \`\`\`yaml
  subjects:
  - kind: Group
    name: oidc:Engineering-Team
    apiGroup: rbac.authorization.k8s.io
  \`\`\``,
  },
  {
    id: 'nkp-q39',
    badge: 'Cluster Topology & Certificate Management',
    title: 'Updating Custom CA Certificate in Cluster Topology Variables',
    scenario:
      'During an upgrade the administrator cannot connect to a registry because of untrusted custom CA certificates. This was originally working but recently the registry had to have their certificates rotated because the company has rolled out a new CA to manage their certificates.',
    prompt: 'Which parameter of the spec.topology.variables[] spec does the administrator need to update in order for the custom CA to be trusted?',
    options: [
      {
        id: 'a',
        text: 'value.imageRegistries',
        isCorrect: false,
        explanation: 'Configures registry endpoints and mirror routing, not node system CA trust stores.',
        nutanixEquivalent: 'imageRegistries Variable',
      },
      {
        id: 'b',
        text: 'value.machineDeployments',
        isCorrect: false,
        explanation: 'Defines worker pool replicas and hardware profiles.',
        nutanixEquivalent: 'machineDeployments Variable',
      },
      {
        id: 'c',
        text: 'value.class',
        isCorrect: false,
        explanation: 'Identifies the ClusterClass template, not cluster runtime variable overrides.',
        nutanixEquivalent: 'ClusterClass Name',
      },
      {
        id: 'd',
        text: 'value.clusterConfig',
        isCorrect: true,
        explanation: 'Correct! In Cluster API (CAPI) and NKP, custom Certificate Authority (CA) certificates for container registries and system trust bundles are declared under `value.clusterConfig` within `spec.topology.variables[]`.',
        nutanixEquivalent: 'spec.topology.variables[] -> value.clusterConfig (Custom CA Trust Bundle)',
      },
    ],
    correctOptionId: 'd',
    keyTakeaway: 'Custom registry CA certificates must be updated under `value.clusterConfig` in the cluster topology variables to inject the trusted roots into all cluster nodes.',
    deepExplanation: `ClusterClass Topology Variables:
- In modern CAPI v1beta1 ClusterClass definitions:
  - \`value.clusterConfig\` houses cluster-wide operational settings, including HTTP proxy definitions and custom CA certificates.
  - Updating this parameter triggers CAPI to push the new CA certificate to containerd and system cert stores across all nodes.`,
  },
  {
    id: 'nkp-q40',
    badge: 'Kommander Resource Optimization',
    title: 'Minimizing System Resources for Kommander Testing on AWS',
    scenario:
      'A Cloud Engineer is deploying an NKP Cluster in AWS. The environment is for testing purposes only, so the AWS team has requested it be deployed to use a minimal set of system resources to reduce cloud subscription fees.',
    prompt: 'Which two parameters should be specified when initializing a Kommander installation, using the nkp install kommander command set? (Choose two.)',
    options: [
      {
        id: 'a',
        text: '--wait-timeout',
        isCorrect: false,
        explanation: 'Governs operation timeout duration, having no effect on system resource consumption.',
        nutanixEquivalent: 'Timeout Parameter',
      },
      {
        id: 'b',
        text: '--init',
        isCorrect: true,
        explanation: 'Correct! The `--init` parameter generates the baseline installer configuration file (kommander.yaml) so that optional heavy platform applications can be disabled or resized before installation.',
        nutanixEquivalent: '--init Configuration Generator',
      },
      {
        id: 'c',
        text: '--request-timeout',
        isCorrect: false,
        explanation: 'Sets client HTTP request timeout thresholds.',
        nutanixEquivalent: 'Request Timeout',
      },
      {
        id: 'd',
        text: '--oyaml',
        isCorrect: true,
        explanation: 'Correct! The `--oyaml` (or `-o yaml`) flag outputs the full declarative YAML installer configuration to stdout so the engineer can redirect and edit resource requests and disable unused applications.',
        nutanixEquivalent: '-o yaml / --oyaml Installer Configuration Output',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'Use `nkp install kommander --init --oyaml > kommander.yaml` to generate the customizable YAML configuration, allowing you to disable resource-intensive applications for minimal test environments.',
    deepExplanation: `Minimal Resource Kommander Deployment:
- Running \`nkp install kommander --init --oyaml > kommander.yaml\` outputs the full catalog specification.
- In \`kommander.yaml\`, engineers can set \`enabled: false\` for high-footprint services (e.g. Thanos, fluent-bit, logging, Thanos compact) or adjust replica counts to 1, significantly cutting EC2 compute costs.`,
  },
];
