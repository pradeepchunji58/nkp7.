import { Question } from '../../types';

export const batch4Questions: Question[] = [
  {
    id: 'nkp-q61',
    badge: 'High Availability & Quorum',
    title: 'Minimum Control Plane Node Count for High Availability',
    scenario:
      'A platform architect is designing a production NKP deployment on Nutanix AHV and must ensure high availability for the control plane and etcd.',
    prompt: 'What is the minimum recommended number of control plane nodes to achieve high availability with etcd quorum?',
    options: [
      {
        id: 'a',
        text: '1 node',
        isCorrect: false,
        explanation: 'A single node has no fault tolerance; loss of the node halts the cluster.',
        nutanixEquivalent: 'Single Node (No HA)',
      },
      {
        id: 'b',
        text: '2 nodes',
        isCorrect: false,
        explanation: 'Two nodes cannot establish quorum if one fails; split-brain condition prevents leader election.',
        nutanixEquivalent: 'Even Node Count (Split-Brain Risk)',
      },
      {
        id: 'c',
        text: '3 nodes',
        isCorrect: true,
        explanation: 'Correct! Raft distributed consensus (used by etcd) requires an odd number of members (2N + 1). A minimum of 3 nodes tolerates 1 node failure while maintaining quorum (majority of 2).',
        nutanixEquivalent: '3-Node Control Plane (Tolerates 1 Node Failure)',
      },
      {
        id: 'd',
        text: '4 nodes',
        isCorrect: false,
        explanation: 'Even numbers do not increase fault tolerance; 4 nodes still only tolerate 1 failure (requires 3 for majority).',
        nutanixEquivalent: '4-Node Even Quorum',
      },
    ],
    correctOptionId: 'c',
    keyTakeaway: 'A minimum of 3 control plane nodes (odd number) is required for production high availability to maintain etcd Raft quorum during a node failure.',
    deepExplanation: `Etcd Quorum Formula:
- Quorum = \`floor(N/2) + 1\`.
- For 3 nodes: Quorum is 2. If 1 fails, 2 remain (2 >= 2), cluster continues processing writes.
- For 5 nodes: Quorum is 3. Tolerates 2 node failures.
- Production NKP clusters on Nutanix AHV are deployed with 3 or 5 control plane VMs distributed across separate AHV hosts.`,
  },
  {
    id: 'nkp-q62',
    badge: 'Automated Diagnostics & Insights',
    title: 'Automated Issue Detection with NKP Insights',
    scenario:
      'An enterprise platform team wants proactive alerting for deprecated Kubernetes APIs, security misconfigurations, and cluster health anomalies before upgrading.',
    prompt: 'Which tool integrated in NKP provides automated detection of cluster configuration issues and deprecated APIs?',
    options: [
      {
        id: 'a',
        text: 'NKP Insights',
        isCorrect: true,
        explanation: 'Correct! NKP Insights continuously analyzes cluster telemetry, manifests, and controller states to report deprecated APIs, security vulnerabilities, resource leaks, and misconfigurations.',
        nutanixEquivalent: 'NKP Insights Diagnostic & Health Engine',
      },
      {
        id: 'b',
        text: 'MetalLB',
        isCorrect: false,
        explanation: 'MetalLB assigns IP addresses to load balancer services.',
        nutanixEquivalent: 'MetalLB Load Balancer',
      },
      {
        id: 'c',
        text: 'Traefik',
        isCorrect: false,
        explanation: 'Traefik is an HTTP ingress controller.',
        nutanixEquivalent: 'Traefik Ingress Proxy',
      },
      {
        id: 'd',
        text: 'Rook-Ceph',
        isCorrect: false,
        explanation: 'Rook-Ceph manages distributed storage clusters.',
        nutanixEquivalent: 'Rook-Ceph Storage',
      },
    ],
    correctOptionId: 'a',
    keyTakeaway: 'NKP Insights provides automated analysis of cluster health, surfacing warnings about deprecated APIs, security flaws, and configuration drifts.',
    deepExplanation: `NKP Insights Capabilities:
- Runs checks against live cluster objects without interrupting workloads.
- Identifies removed or deprecated API versions prior to cluster upgrades.
- Provides actionable remediation recommendations in the Kommander dashboard.`,
  },
  {
    id: 'nkp-q63',
    badge: 'Platform Services & Networking',
    title: 'Automated DNS Synchronization with ExternalDNS',
    scenario:
      'An administrator needs public or corporate DNS records created automatically whenever developers expose an Ingress or LoadBalancer Service.',
    prompt: 'Which platform service in NKP handles dynamic DNS record synchronization with external providers?',
    options: [
      {
        id: 'a',
        text: 'CoreDNS',
        isCorrect: false,
        explanation: 'CoreDNS handles internal cluster DNS resolution within the cluster domain (cluster.local), not external enterprise DNS zones.',
        nutanixEquivalent: 'CoreDNS (Internal Cluster DNS)',
      },
      {
        id: 'b',
        text: 'ExternalDNS',
        isCorrect: true,
        explanation: 'Correct! ExternalDNS is an NKP platform application that watches Kubernetes Services and Ingresses and automatically provisions DNS A/CNAME records in external providers (e.g. AWS Route53, Infoblox, Cloudflare, Bind).',
        nutanixEquivalent: 'ExternalDNS Platform Application',
      },
      {
        id: 'c',
        text: 'Dex',
        isCorrect: false,
        explanation: 'Dex is an identity broker.',
        nutanixEquivalent: 'Dex Identity Service',
      },
      {
        id: 'd',
        text: 'Velero',
        isCorrect: false,
        explanation: 'Velero handles disaster recovery.',
        nutanixEquivalent: 'Velero DR',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'ExternalDNS synchronizes Kubernetes Ingress and Service hostnames with external DNS servers, automating DNS record lifecycle.',
    deepExplanation: `ExternalDNS in NKP:
- Detects the \`spec.rules.host\` in Ingress resources or annotations on LoadBalancer services.
- Calls the external DNS API to dynamically create and delete DNS records matching the cluster's ingress load balancer IP.`,
  },
  {
    id: 'nkp-q64',
    badge: 'Management Cluster Storage',
    title: 'Default Storage Provisioner on NKP Management Cluster',
    scenario:
      'When an NKP Management cluster is installed with full platform services, which distributed storage system is deployed to provide block and filesystem storage classes?',
    prompt: 'What storage provider is configured by default on an NKP management cluster?',
    options: [
      {
        id: 'a',
        text: 'Rook-Ceph (CephBlockPool and CephFilesystem)',
        isCorrect: true,
        explanation: 'Correct! On self-contained NKP management clusters, Rook-Ceph orchestrates Ceph to deliver high-performance CephBlockPool (RBD) and CephFilesystem (CephFS) persistent volumes for logging, monitoring, and registry services.',
        nutanixEquivalent: 'Rook-Ceph Storage Operator (CephBlockPool / CephFS)',
      },
      {
        id: 'b',
        text: 'NFS Client Provisioner only',
        isCorrect: false,
        explanation: 'NFS client provisioner is not the primary distributed storage engine for management services.',
        nutanixEquivalent: 'NFS Client',
      },
      {
        id: 'c',
        text: 'Local Path Provisioner only without replication',
        isCorrect: false,
        explanation: 'Local path lacks data replication across nodes, creating single-point-of-failure risks on management clusters.',
        nutanixEquivalent: 'Local Ephemeral Storage',
      },
      {
        id: 'd',
        text: 'GlusterFS',
        isCorrect: false,
        explanation: 'GlusterFS is deprecated and unsupported in modern Kubernetes.',
        nutanixEquivalent: 'GlusterFS',
      },
    ],
    correctOptionId: 'a',
    keyTakeaway: 'Rook-Ceph manages CephBlockPool and CephFilesystem on the management cluster, providing resilient underlying storage for platform components.',
    deepExplanation: `Rook-Ceph on Management Cluster:
- Converts local disks on management worker nodes into an elastic, fault-tolerant Ceph storage cluster.
- Provides standard StorageClasses: \`ceph-block\` and \`ceph-filesystem\`.
- Underpins Prometheus time-series databases, Grafana state, Loki indexes, and Harbor image blobs.`,
  },
  {
    id: 'nkp-q65',
    badge: 'Service Mesh & Security',
    title: 'Service Mesh and Mutual TLS in NKP',
    scenario:
      'An enterprise security policy mandates mutual TLS (mTLS) encryption, traffic splitting, and distributed tracing across microservices in an NKP cluster.',
    prompt: 'Which platform application in NKP provides an Envoy-based service mesh with mutual TLS?',
    options: [
      {
        id: 'a',
        text: 'Istio',
        isCorrect: true,
        explanation: 'Correct! Istio is the enterprise service mesh integrated into NKP, deploying Envoy sidecars alongside application pods to enforce mTLS encryption, traffic routing rules, and telemetry capture.',
        nutanixEquivalent: 'Istio Service Mesh Platform Application',
      },
      {
        id: 'b',
        text: 'MetalLB',
        isCorrect: false,
        explanation: 'MetalLB is a network load balancer.',
        nutanixEquivalent: 'MetalLB',
      },
      {
        id: 'c',
        text: 'Kube-state-metrics',
        isCorrect: false,
        explanation: 'Kube-state-metrics generates Prometheus metrics from Kubernetes object states.',
        nutanixEquivalent: 'Metrics Exporter',
      },
      {
        id: 'd',
        text: 'Reloader',
        isCorrect: false,
        explanation: 'Reloader watches ConfigMaps and Secrets to restart pods.',
        nutanixEquivalent: 'Reloader',
      },
    ],
    correctOptionId: 'a',
    keyTakeaway: 'Istio provides microservice traffic management, mutual TLS (mTLS) zero-trust encryption, and observability in NKP.',
    deepExplanation: `Istio in NKP:
- Injects Envoy sidecar proxies into application namespaces.
- Enforces strict mTLS between services transparently.
- Integrates with Kiali (visual topology dashboard) and Jaeger (distributed tracing).`,
  },
  {
    id: 'nkp-q66',
    badge: 'Automated Node Remediation',
    title: 'Automated Worker Node Remediation with MachineHealthCheck',
    scenario:
      'A worker node VM on Nutanix AHV suffers an unrecoverable kernel panic and stops reporting kubelet heartbeats.',
    prompt: 'How does NKP automatically remediate the failed node?',
    options: [
      {
        id: 'a',
        text: 'The MachineHealthCheck controller detects the NodeCondition timeout, marks the Machine as unhealthy, and instructs CAPI to provision a replacement VM.',
        isCorrect: true,
        explanation: 'Correct! Cluster API (CAPI) includes MachineHealthCheck CRDs that monitor node health. When a node remains NotReady past the configured timeout, MHC deletes the underlying Machine resource, prompting the MachineDeployment controller to provision a healthy new VM from the AHV template.',
        nutanixEquivalent: 'MachineHealthCheck Automated Remediation & VM Replacement',
      },
      {
        id: 'b',
        text: 'The administrator must manually log into Prism Central and reboot the VM.',
        isCorrect: false,
        explanation: 'Manual intervention is not required; NKP provides automated self-healing.',
        nutanixEquivalent: 'Manual Hypervisor Intervention',
      },
      {
        id: 'c',
        text: 'The cluster permanently drops the worker pool size by 1.',
        isCorrect: false,
        explanation: 'CAPI maintains the desired replica count and will not permanently shrink the pool.',
        nutanixEquivalent: 'Capacity Degradation',
      },
      {
        id: 'd',
        text: 'The CNI restarts all pod interfaces.',
        isCorrect: false,
        explanation: 'If the entire VM is dead, in-guest CNI restarting is impossible.',
        nutanixEquivalent: 'In-guest CNI Restart',
      },
    ],
    correctOptionId: 'a',
    keyTakeaway: 'MachineHealthCheck continuously audits node conditions and triggers declarative VM replacement via Cluster API when an unrecoverable node failure occurs.',
    deepExplanation: `MachineHealthCheck Operation:
- Monitors node conditions such as \`Ready=False\` or \`Ready=Unknown\` exceeding a timeout (e.g. 5 minutes).
- Marks the associated \`Machine\` custom resource as failed.
- The \`MachineDeployment\` controller terminates the failed VM in Prism Central and provisions a brand new machine, cordoning and draining the old node.`,
  },
  {
    id: 'nkp-q67',
    badge: 'Cluster Topology & Standards',
    title: 'Role of ClusterClass in Modern NKP Deployments',
    scenario: 'What is the function and advantage of the ClusterClass abstraction in modern NKP deployments?',
    prompt: 'What is the role of ClusterClass in NKP?',
    options: [
      {
        id: 'a',
        text: 'It is a legacy feature that has been removed from Cluster API.',
        isCorrect: false,
        explanation: 'ClusterClass is the modern standard in CAPI v1beta1, not legacy.',
        nutanixEquivalent: 'Deprecated Feature',
      },
      {
        id: 'b',
        text: 'A reusable, template-driven specification that standardizes control plane, worker pool, and infrastructure configurations across multiple clusters.',
        isCorrect: true,
        explanation: 'Correct! ClusterClass provides an inheritance blueprint that abstracts complex CAPI manifests into a single reusable definition, allowing clusters to be created with minimal variable overrides.',
        nutanixEquivalent: 'ClusterClass Template-Driven Abstraction',
      },
      {
        id: 'c',
        text: 'It manages user password expiration policies.',
        isCorrect: false,
        explanation: 'ClusterClass has no role in user authentication.',
        nutanixEquivalent: 'Password Policy',
      },
      {
        id: 'd',
        text: 'It compiles C++ code for hypervisor drivers.',
        isCorrect: false,
        explanation: 'ClusterClass is a Kubernetes CRD, not a compiler.',
        nutanixEquivalent: 'Code Compiler',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'ClusterClass provides a template-based blueprint that standardizes cluster infrastructure specifications and drastically reduces YAML configuration overhead.',
    deepExplanation: `ClusterClass Mechanics:
- Standardizes \`NutanixCluster\`, \`KubeadmControlPlaneTemplate\`, and \`NutanixMachineTemplate\`.
- Administrators instantiate new clusters with a concise \`topology\` block specifying variables (\`controlPlaneReplicas\`, \`workerReplicas\`, \`prismElementCluster\`).
- Upgrades can be performed by updating the ClusterClass reference.`,
  },
  {
    id: 'nkp-q68',
    badge: 'Cluster Upgrades & CLI Operations',
    title: 'Upgrading a Managed Workload Cluster via NKP CLI',
    scenario:
      'An administrator is ready to upgrade a managed workload cluster named `prod-cluster` to a newer minor version of Kubernetes.',
    prompt: 'Which command initiates the upgrade of the managed cluster using the NKP CLI?',
    options: [
      {
        id: 'a',
        text: 'nkp upgrade cluster --cluster-name prod-cluster',
        isCorrect: true,
        explanation: 'Correct! The command `nkp upgrade cluster --cluster-name <cluster-name>` orchestrates the rolling upgrade of control plane nodes followed by worker node pools.',
        nutanixEquivalent: 'nkp upgrade cluster --cluster-name <name>',
      },
      {
        id: 'b',
        text: 'kubectl upgrade nodes prod-cluster',
        isCorrect: false,
        explanation: 'kubectl has no native `upgrade nodes` command.',
        nutanixEquivalent: 'Invalid Kubectl Command',
      },
      {
        id: 'c',
        text: 'nkp patch cluster --image-new prod-cluster',
        isCorrect: false,
        explanation: '`patch cluster --image-new` is not a valid NKP CLI command.',
        nutanixEquivalent: 'Invalid Flag Syntax',
      },
      {
        id: 'd',
        text: 'prism-cli upgrade k8s --cluster prod-cluster',
        isCorrect: false,
        explanation: 'Prism CLI does not manage declarative Kubernetes Cluster API upgrades directly.',
        nutanixEquivalent: 'Prism CLI Command',
      },
    ],
    correctOptionId: 'a',
    keyTakeaway: 'Use `nkp upgrade cluster --cluster-name <name>` to initiate an automated, rolling upgrade of a managed cluster.',
    deepExplanation: `NKP Cluster Upgrade Procedure:
1. Validates pre-flight conditions and node readiness.
2. Performs rolling replacement of control plane VMs one by one to ensure quorum.
3. Performs rolling replacement of worker node pool VMs adhering to PodDisruptionBudgets (PDBs).`,
  },
  {
    id: 'nkp-q69',
    badge: 'Air-Gapped Container Runtime Configuration',
    title: 'Containerd Registry Mirror Configuration in Air-Gapped Clusters',
    scenario:
      'When deploying an air-gapped NKP cluster, which configuration tells the containerd container runtime on every node to redirect public registry requests to the local enterprise registry mirror?',
    prompt: 'How is containerd configured to pull images from the local mirror in an air-gapped deployment?',
    options: [
      {
        id: 'a',
        text: 'Via containerd registry mirror configuration (hosts.toml / certs.d) injected during node provisioning by cloud-init and Cluster API.',
        isCorrect: true,
        explanation: 'Correct! NKP configures containerd using `/etc/containerd/certs.d/` or `hosts.toml` mirror entries via cloud-init so requests to `docker.io`, `quay.io`, and `registry.k8s.io` resolve to the local mirror registry.',
        nutanixEquivalent: 'Containerd Registry Mirroring (hosts.toml / certs.d)',
      },
      {
        id: 'b',
        text: 'By manually modifying the DNS hosts file on each node after every pod restart.',
        isCorrect: false,
        explanation: 'Manual per-node editing is completely unviable and overwritten during node recreation.',
        nutanixEquivalent: 'Manual Hosts File Modification',
      },
      {
        id: 'c',
        text: 'By running an unauthenticated HTTP proxy inside each container.',
        isCorrect: false,
        explanation: 'Containers do not run internal HTTP proxies to pull their own parent images.',
        nutanixEquivalent: 'In-Container Proxy',
      },
      {
        id: 'd',
        text: 'By disabling TLS verification across all cluster networking.',
        isCorrect: false,
        explanation: 'Disabling TLS does not redirect domain names to private mirror endpoints.',
        nutanixEquivalent: 'TLS Disabling',
      },
    ],
    correctOptionId: 'a',
    keyTakeaway: 'NKP configures containerd registry mirror directives (`hosts.toml` / `certs.d`) during node cloud-init to redirect upstream container pulls to the private darksite registry.',
    deepExplanation: `Containerd Mirror Resolution:
- Containerd inspects the host configuration under \`/etc/containerd/certs.d/<registry-domain>/hosts.toml\`.
- Specifies \`server = "https://private-registry.corp.local/v2/<namespace>"\`.
- Injects the enterprise CA certificate for trusted HTTPS handshake.`,
  },
  {
    id: 'nkp-q70',
    badge: 'Workspace RBAC & Multi-Tenancy',
    title: 'Operational Effect of Creating a WorkspaceRoleBinding',
    scenario: 'In Kommander, what is the operational effect of creating a WorkspaceRoleBinding?',
    prompt: 'What is the effect of creating a WorkspaceRoleBinding in Kommander?',
    options: [
      {
        id: 'a',
        text: 'It permanently deletes all other users in the cluster.',
        isCorrect: false,
        explanation: 'Role bindings grant permissions; they never delete other users.',
        nutanixEquivalent: 'Destructive Account Action',
      },
      {
        id: 'b',
        text: 'It federates and grants specific RBAC permissions (e.g. workspace-admin, workspace-viewer) across all clusters attached to that workspace.',
        isCorrect: true,
        explanation: 'Correct! A WorkspaceRoleBinding binds users or groups to a role across all member clusters in the workspace, automatically synchronizing standard Kubernetes RBAC objects.',
        nutanixEquivalent: 'Federated Multi-Cluster RBAC Synchronization',
      },
      {
        id: 'c',
        text: 'It shuts down all pods in the default namespace.',
        isCorrect: false,
        explanation: 'Role bindings do not terminate pods.',
        nutanixEquivalent: 'Pod Termination',
      },
      {
        id: 'd',
        text: 'It converts the workspace into an AWS EC2 instance.',
        isCorrect: false,
        explanation: 'A workspace is a logical governance boundary, not a cloud VM instance.',
        nutanixEquivalent: 'Cloud Resource Conversion',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'A WorkspaceRoleBinding grants consistent role permissions across all member clusters within a workspace through automated GitOps RBAC synchronization.',
    deepExplanation: `WorkspaceRoleBinding Synchronization:
- Defined once at the Kommander management plane.
- The GitOps controller evaluates member clusters in the workspace.
- Injects corresponding \`ClusterRoleBinding\` or \`RoleBinding\` resources into each cluster automatically, ensuring immediate uniform access.`,
  },
  {
    id: 'nkp-q71',
    badge: 'Observability & Network Protocols',
    title: 'Communication Protocol Between Thanos Sidecar and Thanos Querier',
    scenario:
      'A network security engineer is auditing the internal ports and protocols used between Thanos monitoring components across clusters.',
    prompt: 'Which protocol is used by Thanos Sidecar to communicate with Thanos Querier?',
    options: [
      {
        id: 'a',
        text: 'gRPC over HTTP/2',
        isCorrect: true,
        explanation: 'Correct! Thanos components (Querier, Sidecar, Store Gateway) communicate using high-performance gRPC over HTTP/2 (typically on port 10901) with optional mTLS encryption.',
        nutanixEquivalent: 'gRPC (TCP/10901) over HTTP/2',
      },
      {
        id: 'b',
        text: 'Telnet',
        isCorrect: false,
        explanation: 'Telnet is an unencrypted interactive terminal protocol, not used for modern microservices.',
        nutanixEquivalent: 'Telnet Protocol',
      },
      {
        id: 'c',
        text: 'FTP',
        isCorrect: false,
        explanation: 'FTP is an obsolete file transfer protocol.',
        nutanixEquivalent: 'FTP Protocol',
      },
      {
        id: 'd',
        text: 'SNMP v1',
        isCorrect: false,
        explanation: 'SNMP is a legacy network device protocol.',
        nutanixEquivalent: 'SNMP',
      },
    ],
    correctOptionId: 'a',
    keyTakeaway: 'Thanos Querier communicates with remote Thanos Sidecars using gRPC over HTTP/2 on port 10901 for high-speed streaming metric queries.',
    deepExplanation: `Thanos Cross-Cluster Protocol:
- Thanos Sidecar exposes a gRPC StoreAPI.
- Thanos Querier connects via gRPC to stream time-series chunks directly without intermediate disk writes.
- Can be routed through Ingress controllers using HTTP/2 or over the NKP Secure Tunnel.`,
  },
  {
    id: 'nkp-q72',
    badge: 'AI/ML Workloads & Hardware Acceleration',
    title: 'Benefit of NKP GPU Worker Node Pools with NVIDIA Operator',
    scenario:
      'An enterprise is deploying Generative AI and deep learning training workloads on Nutanix Kubernetes Platform.',
    prompt: 'What is the primary benefit of deploying NKP with GPU worker node pools and the integrated NVIDIA GPU Operator?',
    options: [
      {
        id: 'a',
        text: 'Automating driver installation, container toolkit configuration, and GPU resource scheduling for high-performance AI/ML and LLM inference workloads.',
        isCorrect: true,
        explanation: 'Correct! The NVIDIA GPU Operator on NKP automates kernel driver compilation, container runtime integration, and device plugin registration, enabling pods to request GPUs via standard Kubernetes resource limits.',
        nutanixEquivalent: 'NVIDIA GPU Operator & Accelerated Hardware Scheduling',
      },
      {
        id: 'b',
        text: 'Decreasing network bandwidth latency across the WAN.',
        isCorrect: false,
        explanation: 'GPUs accelerate compute and matrix multiplication, having no effect on WAN routing latency.',
        nutanixEquivalent: 'WAN Latency',
      },
      {
        id: 'c',
        text: 'Replacing the Kubernetes control plane with an ASIC processor.',
        isCorrect: false,
        explanation: 'Control plane nodes run standard CPU-based Kubernetes control services.',
        nutanixEquivalent: 'ASIC Control Plane',
      },
      {
        id: 'd',
        text: 'Disabling container image pull secrets.',
        isCorrect: false,
        explanation: 'GPU acceleration has no relationship to image authentication secrets.',
        nutanixEquivalent: 'Pull Secrets',
      },
    ],
    correctOptionId: 'a',
    keyTakeaway: 'GPU worker node pools paired with the NVIDIA GPU Operator automate driver provisioning and deliver GPU-accelerated computing for AI/ML workloads in NKP.',
    deepExplanation: `GPU Orchestration in NKP:
- Worker nodes are configured with PCI passthrough or vGPU in Nutanix AHV.
- The GPU Operator detects hardware and installs drivers, NVIDIA Container Toolkit, and Kubernetes device plugin.
- Allows pods to declare \`resources.limits: nvidia.com/gpu: 1\` seamlessly.`,
  },
  {
    id: 'nkp-q73',
    badge: 'Troubleshooting & Capacity Planning',
    title: 'Troubleshooting Pending Pods with Insufficient Memory',
    scenario:
      'An administrator observes that several critical application pods are stuck in the Pending state with the event: "0/4 nodes available: 4 Insufficient memory."',
    prompt: 'What is the most appropriate action to resolve this issue?',
    options: [
      {
        id: 'a',
        text: 'Restart the kube-vip static pod.',
        isCorrect: false,
        explanation: 'kube-vip manages the control plane virtual IP; restarting it will not free memory on worker nodes.',
        nutanixEquivalent: 'kube-vip Restart',
      },
      {
        id: 'b',
        text: 'Scale out the worker node pool or optimize pod memory requests.',
        isCorrect: true,
        explanation: 'Correct! The Kubernetes scheduler cannot place pods because the total memory requests exceed available allocatable memory across all worker nodes. Adding worker nodes or lowering memory requests resolves the bottleneck.',
        nutanixEquivalent: 'Scale Out Worker Node Pool / Adjust Resource Requests',
      },
      {
        id: 'c',
        text: 'Delete the CNI network plugin.',
        isCorrect: false,
        explanation: 'Deleting the CNI plugin disrupts all pod networking and worsens cluster health.',
        nutanixEquivalent: 'CNI Deletion',
      },
      {
        id: 'd',
        text: 'Reinstall the Bastion host.',
        isCorrect: false,
        explanation: 'The bastion host plays no role in runtime pod scheduling on worker nodes.',
        nutanixEquivalent: 'Bastion Reinstall',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'When pods fail scheduling due to "Insufficient memory", scale out the worker node pool via CAPI/Autoscaler or adjust pod resource request allocations.',
    deepExplanation: `Kubernetes Scheduler Capacity:
- Scheduler computes: \`Node Allocatable Memory - Sum of Existing Pod Requests\`.
- If the remaining allocatable memory is less than the new pod's \`resources.requests.memory\`, the pod remains \`Pending\`.
- Solution: Increase worker nodes via \`nkp scale nodepool\` or enable Cluster Autoscaler.`,
  },
  {
    id: 'nkp-q74',
    badge: 'Control Plane Architecture',
    title: 'Role of etcd in Nutanix Kubernetes Platform',
    scenario: 'What critical role does etcd perform within an NKP Kubernetes cluster?',
    prompt: 'What is the role of etcd in an NKP cluster?',
    options: [
      {
        id: 'a',
        text: 'Acts as the primary HTTP reverse proxy for client requests.',
        isCorrect: false,
        explanation: 'Ingress and reverse proxying are handled by Traefik/Envoy, not etcd.',
        nutanixEquivalent: 'Reverse Proxy',
      },
      {
        id: 'b',
        text: 'Serves as the distributed, consistent key-value store holding the complete state, configurations, and secrets of the Kubernetes cluster.',
        isCorrect: true,
        explanation: 'Correct! etcd is the authoritative datastore of Kubernetes. It stores all API objects, cluster specifications, secrets, ConfigMaps, and running state with strong Raft consistency.',
        nutanixEquivalent: 'Authoritative Distributed Key-Value Datastore (etcd)',
      },
      {
        id: 'c',
        text: 'Compiles container images into machine code.',
        isCorrect: false,
        explanation: 'etcd does not compile code.',
        nutanixEquivalent: 'Compiler Engine',
      },
      {
        id: 'd',
        text: 'Generates SSL certificates for client web browsers.',
        isCorrect: false,
        explanation: 'Certificate management is handled by cert-manager, not etcd.',
        nutanixEquivalent: 'cert-manager',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'etcd is the authoritative, highly available distributed key-value datastore storing all Kubernetes cluster state, objects, and metadata.',
    deepExplanation: `etcd Characteristics:
- Implements the Raft consensus algorithm.
- Only \`kube-apiserver\` communicates directly with etcd.
- All cluster state modifications (pod creations, node additions, secret updates) are committed as transactions in etcd.`,
  },
  {
    id: 'nkp-q75',
    badge: 'External Cluster Management',
    title: 'Components Installed When Attaching External Clusters to Kommander',
    scenario:
      'An enterprise uses Amazon EKS and Google GKE alongside on-premises NKP clusters. When an administrator attaches these existing public cloud clusters to Kommander, what is deployed onto them?',
    prompt: 'What components are installed on an external cluster when it is attached to Kommander?',
    options: [
      {
        id: 'a',
        text: 'Kommander federation agent, monitoring sidecars, and cluster management controllers.',
        isCorrect: true,
        explanation: 'Correct! Attaching an external cluster deploys the lightweight Kommander agent stack, including federated Prometheus/Thanos sidecars, Flux GitOps synchronization agents, and tunnel proxies.',
        nutanixEquivalent: 'Kommander Federation Agent Stack & Observability Sidecars',
      },
      {
        id: 'b',
        text: 'A complete rewrite of the Linux kernel.',
        isCorrect: false,
        explanation: 'Attaching a cluster is non-invasive and does not recompile or replace host OS kernels.',
        nutanixEquivalent: 'Kernel Replacement',
      },
      {
        id: 'c',
        text: 'A complete Nutanix AHV hypervisor inside the cloud provider.',
        isCorrect: false,
        explanation: 'External clusters retain their native cloud infrastructure (AWS Nitro / Google Cloud VM).',
        nutanixEquivalent: 'Hypervisor Emulation',
      },
      {
        id: 'd',
        text: 'Nothing; attached clusters cannot be communicated with.',
        isCorrect: false,
        explanation: 'Kommander deploys agents to manage, monitor, and synchronize policies across attached clusters.',
        nutanixEquivalent: 'No-op Management',
      },
    ],
    correctOptionId: 'a',
    keyTakeaway: 'Attaching an external cluster (EKS, GKE, AKS) deploys the Kommander agent stack, enabling federated observability, GitOps application delivery, and centralized governance.',
    deepExplanation: `Multi-Cloud Cluster Attachment:
- Kommander connects using the cluster's kubeconfig.
- Deploys \`kommander-cluster-agent\` and GitOps controllers.
- Connects local Prometheus to Thanos Querier on the management cluster.
- Allows unified dashboarding and governance across hybrid cloud estates.`,
  },
];
