import express from "express";
import path from "path";
import fs from "fs";
import dotenv from "dotenv";
import { GoogleGenAI, Modality } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));

// Lazy Gemini client helper
let aiClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY environment variable is missing.");
    }
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Convert 24kHz 16-bit Mono PCM buffer to standard RIFF WAV buffer
function pcmToWav(pcmData: Buffer, sampleRate = 24000, numChannels = 1, bitsPerSample = 16): Buffer {
  // If already has RIFF header, return as is
  if (pcmData.length >= 4 && pcmData.toString("ascii", 0, 4) === "RIFF") {
    return pcmData;
  }

  const byteRate = (sampleRate * numChannels * bitsPerSample) / 8;
  const blockAlign = (numChannels * bitsPerSample) / 8;
  const dataSize = pcmData.length;
  const header = Buffer.alloc(44);

  // RIFF chunk descriptor
  header.write("RIFF", 0);
  header.writeUInt32LE(36 + dataSize, 4);
  header.write("WAVE", 8);

  // "fmt " sub-chunk
  header.write("fmt ", 12);
  header.writeUInt32LE(16, 16); // Subchunk1Size
  header.writeUInt16LE(1, 20); // AudioFormat 1 = Linear PCM
  header.writeUInt16LE(numChannels, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE(byteRate, 28);
  header.writeUInt16LE(blockAlign, 32);
  header.writeUInt16LE(bitsPerSample, 34);

  // "data" sub-chunk
  header.write("data", 36);
  header.writeUInt32LE(dataSize, 40);

  return Buffer.concat([header, pcmData]);
}

// API Health Check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", timestamp: new Date().toISOString() });
});

// Download full project ZIP endpoint
app.get("/api/download-zip", (req, res) => {
  const filePath = path.join(process.cwd(), "public", "nkp-exam-app.zip");
  if (fs.existsSync(filePath)) {
    res.setHeader("Content-Disposition", 'attachment; filename="nkp-exam-app.zip"');
    res.setHeader("Content-Type", "application/zip");
    res.sendFile(filePath);
  } else {
    res.status(404).json({ error: "Zip file not found. Please try again in a moment." });
  }
});

// Server-side in-memory audio cache: Map<`${voice}:${normalizedText}`, { audio: string; mimeType: string }>
const serverAudioCache = new Map<string, { audio: string; mimeType: string }>();

// Text-To-Speech endpoint using gemini-3.1-flash-tts-preview with caching & quota recovery
app.post("/api/tts", async (req, res) => {
  try {
    const { text, voice = "Kore" } = req.body;
    if (!text || typeof text !== "string") {
      return res.status(400).json({ error: "Missing or invalid 'text' field." });
    }

    const validVoices = ["Kore", "Puck", "Charon", "Fenrir", "Zephyr"];
    const voiceName = validVoices.includes(voice) ? voice : "Kore";
    const normalizedText = text.trim();

    // Check server-side cache first to save quota
    const cacheKey = `${voiceName}:${normalizedText}`;
    if (serverAudioCache.has(cacheKey)) {
      const cached = serverAudioCache.get(cacheKey)!;
      return res.json({
        audio: cached.audio,
        mimeType: cached.mimeType,
        voice: voiceName,
        cached: true,
      });
    }

    const ai = getGenAI();

    const response = await ai.models.generateContent({
      model: "gemini-3.1-flash-tts-preview",
      contents: [{ parts: [{ text: normalizedText }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName },
          },
        },
      },
    });

    const candidate = response.candidates?.[0];
    const audioPart = candidate?.content?.parts?.find((p) => p.inlineData?.data);

    if (!audioPart || !audioPart.inlineData?.data) {
      throw new Error("No audio returned from Gemini 3.1 Flash TTS.");
    }

    const rawBase64 = audioPart.inlineData.data;
    const incomingMime = audioPart.inlineData.mimeType || "audio/pcm;rate=24000";

    // Format raw PCM to universally playable WAV
    const rawBuffer = Buffer.from(rawBase64, "base64");
    const wavBuffer = pcmToWav(rawBuffer, 24000, 1, 16);
    const wavBase64 = wavBuffer.toString("base64");

    // Cache the synthesized audio in server memory
    serverAudioCache.set(cacheKey, {
      audio: wavBase64,
      mimeType: "audio/wav",
    });

    res.json({
      audio: wavBase64,
      mimeType: "audio/wav",
      originalMimeType: incomingMime,
      voice: voiceName,
      cached: false,
    });
  } catch (err: any) {
    const errMsg = err?.message || String(err);
    const isQuotaError =
      err?.status === 429 ||
      errMsg.includes("429") ||
      errMsg.includes("quota") ||
      errMsg.includes("RESOURCE_EXHAUSTED") ||
      errMsg.includes("limit: 3");

    if (isQuotaError) {
      console.warn("Gemini TTS quota exceeded (3 RPM free tier). Signaling client for browser speech fallback.");
      return res.status(429).json({
        error: "QUOTA_EXCEEDED",
        message: "Gemini 3.1 Flash TTS rate limit reached (3 requests/minute). Switching to browser speech engine.",
        retryAfter: 15,
      });
    }

    console.error("TTS generation error:", err);
    res.status(500).json({
      error: errMsg || "Failed to generate speech audio.",
    });
  }
});

// AI Q&A Endpoint for Nutanix Kubernetes Platform deep questions
app.post("/api/ask", async (req, res) => {
  try {
    const { query, context } = req.body;
    if (!query) {
      return res.status(400).json({ error: "Query is required" });
    }

    const ai = getGenAI();
    const systemPrompt = `You are a certified Nutanix Kubernetes Platform (NKP) Solutions Architect and technical examiner.
Provide clear, accurate, concise, and technically authoritative answers regarding:
- NKP architecture, bastion host prerequisites, bootstrap Kind clusters, and management/workload clusters.
- Nutanix AHV, Prism Central, Nutanix CSI, Nutanix Volumes, CAPI (Cluster API), and air-gapped deployments.
Keep explanations structured with key takeaways, command examples where relevant, and clear distinctions between architectural components.`;

    const prompt = `Context: ${context || "Nutanix Kubernetes Platform (NKP) bastion host prerequisites and deployment."}
Question: ${query}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt,
      config: {
        systemInstruction: systemPrompt,
      },
    });

    res.json({ answer: response.text });
  } catch (err: any) {
    console.error("Ask AI error:", err);
    res.status(500).json({ error: err.message || "Failed to generate response." });
  }
});

// Setup Vite middleware / static serving
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
