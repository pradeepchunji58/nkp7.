import React, { useState, useEffect } from 'react';
import {
  CheckCircle2,
  XCircle,
  Volume2,
  Sparkles,
  HelpCircle,
  ArrowRight,
  RotateCcw,
  Check,
  ShieldCheck,
  Server,
  Database,
  Cpu,
  Archive,
  Layers
} from 'lucide-react';
import { Question, OptionKey } from '../types';
import { audioService } from '../utils/audioPlayer';
import { AVAILABLE_VOICES } from '../data/nkpQuestions';

interface QuestionCardProps {
  question: Question;
  selectedOption: OptionKey | null;
  onSelectOption: (key: OptionKey) => void;
  isSubmitted: boolean;
  onSubmit: () => void;
  onReset: () => void;
}

export const QuestionCard: React.FC<QuestionCardProps> = ({
  question,
  selectedOption,
  onSelectOption,
  isSubmitted,
  onSubmit,
  onReset,
}) => {
  const [activeVoice, setActiveVoice] = useState<'Kore' | 'Puck' | 'Charon' | 'Fenrir' | 'Zephyr'>('Kore');
  const [isPlayingQuestion, setIsPlayingQuestion] = useState(false);

  useEffect(() => {
    const unsub = audioService.subscribe((state) => {
      setIsPlayingQuestion(state.isPlaying && state.currentTextId === `question-${question.id}`);
      if (state.voice) {
        setActiveVoice(state.voice as any);
      }
    });
    return unsub;
  }, [question.id]);

  const handleListenQuestion = () => {
    const speechScript = `Nutanix Kubernetes Platform Exam Review. Scenario: ${question.scenario} Question: ${question.prompt}. Option A: ${question.options[0].text}. Option B: ${question.options[1].text}. Option C: ${question.options[2].text}. Option D: ${question.options[3].text}.`;
    audioService.speakText(`question-${question.id}`, `Question & Options (${question.title})`, speechScript, activeVoice);
  };

  const getOptionIcon = (optKey: OptionKey) => {
    switch (optKey) {
      case 'a':
        return <Database className="w-4 h-4 text-amber-500" />;
      case 'b':
        return <Cpu className="w-4 h-4 text-blue-500" />;
      case 'c':
        return <Server className="w-4 h-4 text-emerald-500" />;
      case 'd':
        return <Archive className="w-4 h-4 text-purple-500" />;
      default:
        return <Layers className="w-4 h-4 text-slate-500" />;
    }
  };

  return (
    <div
      id="question-card"
      className="bg-white rounded-2xl border border-slate-200/90 shadow-sm hover:shadow-md transition-shadow overflow-hidden"
    >
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1.5 flex-wrap">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
              <ShieldCheck className="w-3.5 h-3.5" />
              {question.badge}
            </span>
            <span className="text-xs text-slate-400 font-mono">ID: {question.id.toUpperCase()}</span>
          </div>
          <h2 className="text-xl font-bold tracking-tight text-white">{question.title}</h2>
        </div>

        {/* TTS Action Button & Voice Quick Select */}
        <div className="flex items-center gap-2 flex-shrink-0">
          <select
            id="select-voice-question"
            value={activeVoice}
            onChange={(e) => {
              const v = e.target.value as any;
              setActiveVoice(v);
              audioService.setVoice(v);
            }}
            className="bg-slate-800 border border-slate-700 text-slate-200 text-xs rounded-lg px-2.5 py-2 font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-none"
            title="TTS Voice Profile"
          >
            {AVAILABLE_VOICES.map((v) => (
              <option key={v.id} value={v.id}>
                {v.name} ({v.tone.split(' ')[0]})
              </option>
            ))}
          </select>

          <button
            id="btn-listen-question"
            onClick={handleListenQuestion}
            className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold shadow-sm transition-all ${
              isPlayingQuestion
                ? 'bg-emerald-500 text-slate-950 ring-2 ring-emerald-300'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white active:scale-95'
            }`}
            title="Listen to question and options via Gemini 3.1 Flash TTS"
          >
            <Volume2 className={`w-4 h-4 ${isPlayingQuestion ? 'animate-pulse' : ''}`} />
            <span>{isPlayingQuestion ? 'Reading Aloud...' : 'Read Aloud (TTS)'}</span>
            <Sparkles className="w-3 h-3 text-emerald-200" />
          </button>
        </div>
      </div>

      {/* Scenario & Question Prompt */}
      <div className="p-5 sm:p-7 space-y-6">
        <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-slate-700 text-sm leading-relaxed">
          <div className="flex items-start gap-2.5">
            <HelpCircle className="w-4 h-4 text-emerald-600 mt-0.5 flex-shrink-0" />
            <div>
              <p className="font-semibold text-slate-900 mb-1">Deployment Scenario:</p>
              <p>{question.scenario}</p>
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
            <span>{question.prompt}</span>
          </h3>

          {/* Multiple Choice Options List */}
          <div className="space-y-3" role="radiogroup" aria-label="Multiple Choice Options">
            {question.options.map((option) => {
              const isSelected = selectedOption === option.id;
              const isOptionCorrect = option.id === question.correctOptionId;

              let containerStyles =
                'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50/80 text-slate-800';
              let badgeStyles = 'bg-slate-100 text-slate-700 border-slate-300';

              if (isSelected && !isSubmitted) {
                containerStyles =
                  'border-emerald-600 bg-emerald-50/40 text-emerald-950 ring-2 ring-emerald-500/30';
                badgeStyles = 'bg-emerald-600 text-white border-emerald-600';
              } else if (isSubmitted) {
                if (isOptionCorrect) {
                  containerStyles =
                    'border-emerald-500 bg-emerald-50/70 text-emerald-950 ring-2 ring-emerald-500/40';
                  badgeStyles = 'bg-emerald-600 text-white border-emerald-600';
                } else if (isSelected && !isOptionCorrect) {
                  containerStyles =
                    'border-red-400 bg-red-50/70 text-red-950 ring-2 ring-red-400/40';
                  badgeStyles = 'bg-red-600 text-white border-red-600';
                } else {
                  containerStyles = 'border-slate-200 bg-slate-50/60 opacity-60 text-slate-600';
                }
              }

              return (
                <div
                  key={option.id}
                  id={`option-container-${option.id}`}
                  onClick={() => !isSubmitted && onSelectOption(option.id)}
                  className={`relative p-4 rounded-xl border-2 transition-all cursor-pointer flex items-start gap-3.5 ${containerStyles}`}
                >
                  {/* Option Letter Tag */}
                  <div
                    className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs uppercase flex-shrink-0 border ${badgeStyles}`}
                  >
                    {isSubmitted && isOptionCorrect ? (
                      <Check className="w-4 h-4 stroke-[3]" />
                    ) : isSubmitted && isSelected && !isOptionCorrect ? (
                      <XCircle className="w-4 h-4" />
                    ) : (
                      option.id
                    )}
                  </div>

                  {/* Option Text & Description */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="p-1 rounded bg-slate-100/80">{getOptionIcon(option.id)}</span>
                      <p className="font-semibold text-sm sm:text-base leading-snug">
                        {option.text}
                      </p>
                    </div>

                    {/* Explanatory feedback when submitted */}
                    {isSubmitted && (
                      <div className="mt-2.5 pt-2.5 border-t border-slate-200/80 text-xs leading-relaxed">
                        {isOptionCorrect ? (
                          <div className="flex items-start gap-1.5 text-emerald-800 font-medium">
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 flex-shrink-0 mt-0.5" />
                            <span>{option.explanation}</span>
                          </div>
                        ) : (
                          <div className="flex items-start gap-1.5 text-slate-600">
                            <span className="font-semibold text-slate-800 flex-shrink-0">
                              Distractor Analysis:
                            </span>
                            <span>{option.explanation}</span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Action Controls */}
        <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-xs text-slate-500">
            {isSubmitted ? (
              <span className="inline-flex items-center gap-1.5 font-medium text-slate-700">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                Review submitted. See detailed architectural analysis below.
              </span>
            ) : (
              <span>Select an option (a, b, c, or d) and check your answer.</span>
            )}
          </div>

          <div className="flex items-center gap-2.5 w-full sm:w-auto">
            {isSubmitted ? (
              <button
                id="btn-retry-question"
                onClick={onReset}
                className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-semibold border border-slate-300 hover:bg-slate-100 text-slate-700 transition-colors w-full sm:w-auto"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Try Again
              </button>
            ) : (
              <button
                id="btn-check-answer"
                onClick={onSubmit}
                disabled={!selectedOption}
                className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold bg-slate-900 hover:bg-slate-800 text-white disabled:opacity-40 disabled:cursor-not-allowed shadow-sm transition-all w-full sm:w-auto"
              >
                <span>Check Answer</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Highlight Result Callout when submitted */}
        {isSubmitted && (
          <div
            id="result-banner"
            className={`p-4 rounded-xl border ${
              selectedOption === question.correctOptionId
                ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                : 'bg-amber-50 border-amber-300 text-amber-950'
            }`}
          >
            <div className="flex items-start gap-3">
              {selectedOption === question.correctOptionId ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
              ) : (
                <HelpCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
              )}
              <div>
                <h4 className="font-bold text-sm">
                  {selectedOption === question.correctOptionId
                    ? 'Excellent! You selected the correct answer.'
                    : `Correct Answer: Option (${question.correctOptionId.toUpperCase()}) — ${
                        question.options.find((o) => o.id === question.correctOptionId)?.text
                      }`}
                </h4>
                <p className="text-xs mt-1 leading-relaxed opacity-90">{question.keyTakeaway}</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
