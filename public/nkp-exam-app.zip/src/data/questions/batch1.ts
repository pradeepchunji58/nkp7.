import { Question } from '../../types';

export const batch1Questions: Question[] = [
  {
    id: 'nkp-q1',
    badge: 'Centralized Monitoring & Observability',
    title: 'Attached Cluster Identification in Centralized Monitoring',
    scenario:
      'In the centralized monitoring view on the management cluster, a team needs to tell which attached cluster a given metric or alert came from.',
    prompt: 'What identifies each attached cluster there?',
    options: [
      {
        id: 'a',
        text: "The external IP address of the cluster's load balancer",
        isCorrect: false,
        explanation: 'Load balancer IPs are network layer details that can change, overlap in private subnets, or be absent in private ingress models.',
        nutanixEquivalent: 'Cluster MetalLB / Ingress IP',
      },
      {
        id: 'b',
        text: "A hostname of the cluster's management control plane node",
        isCorrect: false,
        explanation: 'Control plane hostnames identify individual node instances (e.g., node-cp-0), not the entire cluster entity.',
        nutanixEquivalent: 'Control Plane VM Node Name',
      },
      {
        id: 'c',
        text: 'The name assigned to the cluster at creation time',
        isCorrect: true,
        explanation: 'Correct! In Kommander centralized multi-cluster monitoring (federated Prometheus and Thanos), all metrics and alerts are tagged with the external label cluster matching the cluster name assigned at creation or attachment.',
        nutanixEquivalent: 'Kommander Cluster Name Label (cluster: <cluster-name>)',
      },
      {
        id: 'd',
        text: 'A monitoring ID matching the kube-system namespace UID',
        isCorrect: false,
        explanation: 'Internal Kubernetes namespace UIDs are UUID strings used internally by the API server, not used for human-readable multi-cluster metric aggregation.',
        nutanixEquivalent: 'Internal Kubernetes Namespace UID',
      },
    ],
    correctOptionId: 'c',
    keyTakeaway: 'In Kommander centralized monitoring, Thanos and federated Prometheus tag all metrics and alerts with the cluster label matching the cluster name assigned at creation time.',
    deepExplanation: `In Nutanix Kubernetes Platform (NKP) and Kommander multi-cluster management:
1. Every managed and attached cluster runs Prometheus and a Thanos sidecar.
2. An external label (\`cluster: <cluster-name>\`) is injected into the local Prometheus configuration, where \`<cluster-name>\` is the unique name given at creation time.
3. The centralized Thanos Querier on the management cluster queries all stores and allows Grafana to filter and group by this \`cluster\` label.
4. Alertmanager routes notifications based on the \`cluster\` tag so SREs know immediately which cluster triggered the alert.`,
  },
  {
    id: 'nkp-q2',
    badge: 'Identity & Access Management (IAM)',
    title: 'Active Directory Group OIDC Pre-seeding in Kommander',
    scenario:
      'NKP-Cluster-Admin AD Group users cannot login to Kommander and the appropriate role binding is completed. AD Groups Demo Users and NKP-Admins are working fine.',
    prompt: 'What is the issue?',
    options: [
      {
        id: 'a',
        text: 'NKP-Cluster-Admin is a reserved group requiring SAML',
        isCorrect: false,
        explanation: 'Kommander does not reserve this group name or mandate SAML over OIDC.',
        nutanixEquivalent: 'SAML Connector Profile',
      },
      {
        id: 'b',
        text: 'NKP-Cluster-Admin is a system group and cannot be used',
        isCorrect: false,
        explanation: 'System groups in Kubernetes are typically system:*, whereas AD groups are user-defined directory entities.',
        nutanixEquivalent: 'Kubernetes System Group',
      },
      {
        id: 'c',
        text: 'OIDC is only compatible with GitHub IDP, not Active Directory',
        isCorrect: false,
        explanation: 'Dex in NKP supports Active Directory (LDAP), SAML 2.0, Okta, Azure AD, and GitHub seamlessly.',
        nutanixEquivalent: 'Dex Identity Provider Connectors',
      },
      {
        id: 'd',
        text: 'NKP-Cluster-Admin added without pre-seeding it with OIDC:',
        isCorrect: true,
        explanation: 'Correct! When configuring groups from an external Identity Provider in Kommander/Dex, group references in RoleBindings must be properly prefixed or pre-seeded with the oidc: prefix (e.g. oidc:NKP-Cluster-Admin) to match the claims issued by Dex.',
        nutanixEquivalent: 'Dex OIDC Group Claim Prefix (oidc:<group-name>)',
      },
    ],
    correctOptionId: 'd',
    keyTakeaway: 'External IDP groups in NKP role bindings require proper OIDC group prefixing (oidc:<group-name>) and pre-seeding so Dex claims align with Kubernetes RBAC subjects.',
    deepExplanation: `In Kommander Identity Management:
- Dex serves as the central OIDC broker connected to Active Directory/LDAP.
- When Dex issues ID tokens, group memberships are transformed into group claims.
- Kubernetes RoleBindings that bind external groups must match the exact token claim, which uses the \`oidc:\` prefix (or must be pre-seeded in the IDP connector group mappings). Without the \`oidc:\` claim prefix, authorization checks evaluate to unauthorized.`,
  },
  {
    id: 'nkp-q3',
    badge: 'Deployment Prerequisites & Architecture',
    title: 'Primary Purpose of the Bastion Host in NKP',
    scenario:
      'An administrator is preparing to deploy a Kubernetes cluster using Nutanix Kubernetes Platform (NKP). As part of the deployment prerequisites, a bastion host must be configured.',
    prompt: 'What is the primary purpose of the bastion host?',
    options: [
      {
        id: 'a',
        text: 'Provide a storage platform for Kubernetes persistent volume provisioning.',
        isCorrect: false,
        explanation: 'Storage provisioning is handled by Nutanix Unified Storage, Nutanix CSI driver, and Nutanix Volumes/Objects.',
        nutanixEquivalent: 'Nutanix CSI / Nutanix Volumes',
      },
      {
        id: 'b',
        text: 'Provide a dedicated platform for running production containerized applications.',
        isCorrect: false,
        explanation: 'Production applications run on worker nodes in the workload cluster, never on the bastion host.',
        nutanixEquivalent: 'NKP Worker Node Pool',
      },
      {
        id: 'c',
        text: 'Provide a centralized system for deployment and management operations.',
        isCorrect: true,
        explanation: 'Correct! The bastion host serves as the dedicated administrative jumping-off point that runs the NKP CLI, hosts the bootstrap Kind cluster, manages SSH access, and orchestrates deployment and lifecycle management.',
        nutanixEquivalent: 'NKP Bastion Jump Host / Management Operator Machine',
      },
      {
        id: 'd',
        text: 'Provide a backup platform for recovering failed Kubernetes workloads.',
        isCorrect: false,
        explanation: 'Backups are managed by Velero and stored in S3-compatible object storage such as Nutanix Objects.',
        nutanixEquivalent: 'Velero / Nutanix Objects S3',
      },
    ],
    correctOptionId: 'c',
    keyTakeaway: 'The bastion host is the secure, centralized administrative system used to run the NKP CLI, create temporary bootstrap clusters, and orchestrate cluster provisioning and day-2 operations.',
    deepExplanation: `The Bastion Host in NKP:
1. **Tooling Environment**: Contains the required CLI binaries (nkp, kubectl, helm, docker).
2. **Bootstrap Cluster Host**: Runs the temporary Kind (Kubernetes-in-Docker) cluster during initial CAPI initialization.
3. **Security Boundary**: Acts as a jump host to reach private control plane and worker nodes without exposing them to public networks.
4. **Air-Gapped Registry Host**: In dark sites, can also host or seed the local container registry with the NKP bundle.`,
  },
  {
    id: 'nkp-q4',
    badge: 'Cluster Lifecycle Management',
    title: 'Clean Decommission Sequencing for NKP Environment',
    scenario:
      'A team plans to decommission an entire NKP environment that includes a management cluster and several managed clusters, all created through Kommander.',
    prompt: 'To remove everything cleanly, how should the deletion be sequenced?',
    options: [
      {
        id: 'a',
        text: 'Delete only the management cluster, which removes the rest.',
        isCorrect: false,
        explanation: 'Deleting the management cluster first orphans the managed clusters, leaving active VMs and storage volumes consuming hypervisor resources.',
        nutanixEquivalent: 'Orphaned Workload Infrastructure',
      },
      {
        id: 'b',
        text: 'Delete the managed clusters first, then the management cluster.',
        isCorrect: true,
        explanation: 'Correct! You must always delete managed and workload clusters first while the management cluster Cluster API (CAPI) controllers and Kommander are healthy to cleanly delete infrastructure VMs, load balancers, and persistent volumes, followed finally by the management cluster.',
        nutanixEquivalent: 'Ordered CAPI Cluster Deletion Workflow',
      },
      {
        id: 'c',
        text: 'Delete the management cluster first, then the managed clusters.',
        isCorrect: false,
        explanation: 'Without the management cluster, CAPI controllers are gone, making clean declarative teardown of managed clusters impossible via CLI.',
        nutanixEquivalent: 'Broken Controller State',
      },
      {
        id: 'd',
        text: 'Delete all clusters simultaneously from the bastion VM.',
        isCorrect: false,
        explanation: 'Simultaneous deletion creates race conditions where management controllers may terminate before managed cluster finalizers complete.',
        nutanixEquivalent: 'Race Condition Teardown',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'Always delete managed workload clusters first so the management cluster CAPI controllers can release all cloud/hypervisor resources before destroying the management cluster.',
    deepExplanation: `Order of Operations for Decommissioning NKP:
1. Delete all Workload / Managed clusters via \`nkp delete cluster --cluster-name <name>\` or the Kommander UI.
2. Verify that all cloud/AHV VMs, load balancers, and PVCs have been deleted.
3. For self-managed management clusters, create a temporary bootstrap cluster on the bastion host, move CAPI resources to it, and delete the management cluster.
4. Finally, clean up the bootstrap cluster with \`nkp delete bootstrap\`.`,
  },
  {
    id: 'nkp-q5',
    badge: 'Identity & Access Management (IAM)',
    title: 'AD Group Kommander UI Authorization Failure',
    scenario:
      'An administrator has successfully configured an AD IDP and just added in the AD group named "NKP Observability". However, when trying to login to the Kommander UI, authorization fails.',
    prompt: 'What is the likely reason?',
    options: [
      {
        id: 'a',
        text: 'Observability groups can only access Prometheus directly.',
        isCorrect: false,
        explanation: 'Users access observability dashboards through the unified Kommander UI and centralized Grafana proxy.',
        nutanixEquivalent: 'Kommander Unified Observability Portal',
      },
      {
        id: 'b',
        text: 'All users by default have access to K8 resources and is likely an issue connecting to AD.',
        isCorrect: false,
        explanation: 'Kubernetes and Kommander enforce zero-trust role-based access; users have no default permissions without explicit role bindings.',
        nutanixEquivalent: 'Zero-Trust Default Deny RBAC',
      },
      {
        id: 'c',
        text: 'Observability groups can only access Grafana directly.',
        isCorrect: false,
        explanation: 'Grafana is integrated into the Kommander UI; users do not require standalone direct access.',
        nutanixEquivalent: 'Grafana Ingress Proxy',
      },
      {
        id: 'd',
        text: 'The Role Binding was never created allowing access to the NKP UI.',
        isCorrect: true,
        explanation: 'Correct! Authenticating via AD only verifies identity. To access the Kommander UI and workspace resources, a WorkspaceRoleBinding or GlobalRoleBinding must be created linking the group to a role with UI access.',
        nutanixEquivalent: 'WorkspaceRoleBinding / GlobalRoleBinding',
      },
    ],
    correctOptionId: 'd',
    keyTakeaway: 'Authentication (verifying user credentials via AD) is distinct from Authorization. Without a corresponding RoleBinding in Kommander, users will be denied access to the UI.',
    deepExplanation: `Kommander RBAC Mechanics:
- Step 1 (Authentication): Active Directory validates credentials through Dex and issues a signed token.
- Step 2 (Authorization): When the user loads the Kommander UI, the API server checks for a RoleBinding or ClusterRoleBinding referencing their group claim (e.g. \`oidc:NKP Observability\`).
- If no binding exists, the user receives an HTTP 403 Forbidden error upon UI access.`,
  },
  {
    id: 'nkp-q6',
    badge: 'Nutanix AHV Infrastructure Integration',
    title: 'STORAGE_CONTAINER_NAME Environment Variable in Nutanix Bootstrap',
    scenario:
      'A Platform engineer is creating a new bootstrap cluster to deploy NKP on Nutanix.',
    prompt: 'What does the STORAGE_CONTAINER_NAME reference when setting the environment variables?',
    options: [
      {
        id: 'a',
        text: 'The CSI name used for provisioning initial pods',
        isCorrect: false,
        explanation: 'The CSI driver is named csi.nutanix.com, not defined by this storage container variable.',
        nutanixEquivalent: 'Nutanix CSI Driver Name',
      },
      {
        id: 'b',
        text: 'The storage container name needed in an Air-Gapped environment',
        isCorrect: false,
        explanation: 'Storage containers in Nutanix Prism are identical whether in air-gapped or connected environments.',
        nutanixEquivalent: 'Air-Gapped Registry Store',
      },
      {
        id: 'c',
        text: 'The Docker Container used by the bootstrap VM',
        isCorrect: false,
        explanation: 'Docker containers on the bootstrap VM are Kind node containers, not Nutanix storage containers.',
        nutanixEquivalent: 'Kind Container Runtime',
      },
      {
        id: 'd',
        text: 'The name of the Storage Container in Prism Element',
        isCorrect: true,
        explanation: 'Correct! STORAGE_CONTAINER_NAME specifies the Prism Element storage pool container where virtual machine OS disks (vDisks) will be allocated for control plane and worker nodes.',
        nutanixEquivalent: 'Prism Element Storage Container',
      },
    ],
    correctOptionId: 'd',
    keyTakeaway: 'STORAGE_CONTAINER_NAME refers to the storage container in Prism Element where Nutanix AHV creates the virtual disks (vDisks) for the cluster nodes.',
    deepExplanation: `In the Nutanix Cloud Infrastructure (NCI) architecture:
- Nutanix AOS creates logical Storage Containers atop Storage Pools.
- During NKP deployment on AHV, CAPI interacts with Prism Central / Prism Element using these environment variables (\`NUTANIX_PRISM_ELEMENT_CLUSTER_NAME\`, \`STORAGE_CONTAINER_NAME\`) to clone OS images and allocate VM disks into the designated storage container.`,
  },
  {
    id: 'nkp-q7',
    badge: 'Cluster Autoscaling & Resource Management',
    title: 'Cluster Autoscaler Scale-Down Prevention',
    scenario:
      'An administrator is observing a 4-node NKP cluster with Cluster Autoscaling configured. There is very low utilization in the cluster, but the cluster has not scaled down.',
    prompt: 'What is preventing the scale-down action from occurring?',
    options: [
      {
        id: 'a',
        text: 'A node has "cluster-autoscaler.kubernetes.io/scale-down-disabled": "true" set.',
        isCorrect: true,
        explanation: 'Correct! The annotation cluster-autoscaler.kubernetes.io/scale-down-disabled: "true" on a node explicitly instructs the autoscaler engine never to evaluate or terminate that specific node during scale-down calculations.',
        nutanixEquivalent: 'Node Scale-Down Protection Annotation',
      },
      {
        id: 'b',
        text: 'The sum of the CPU requests and Memory requests are smaller than 50% of the node\'s allocatable flag.',
        isCorrect: false,
        explanation: 'Low utilization under 50% is the exact condition that triggers scale-down, not prevents it.',
        nutanixEquivalent: 'Autoscaler Utilization Threshold',
      },
      {
        id: 'c',
        text: 'cluster.x-k8s.io/cluster-api-autoscaler-node-group-min-size is set to 3.',
        isCorrect: false,
        explanation: 'With a 4-node cluster and min-size of 3, the cluster would be eligible to scale down 1 node (from 4 to 3).',
        nutanixEquivalent: 'Node Group Min Size (3)',
      },
      {
        id: 'd',
        text: 'A node has been in the unneeded state for 15 minutes.',
        isCorrect: false,
        explanation: 'Being unneeded for 15 minutes exceeds the default scale-down unneeded time (typically 10 minutes) and would trigger termination.',
        nutanixEquivalent: 'Scale Down Unneeded Time',
      },
    ],
    correctOptionId: 'a',
    keyTakeaway: 'The annotation cluster-autoscaler.kubernetes.io/scale-down-disabled: "true" on a node explicitly prevents Cluster Autoscaler from terminating that node.',
    deepExplanation: `Cluster Autoscaler Scale-Down Rules:
- A node is considered a candidate for removal if its utilization (sum of requested CPU/memory) is below the threshold (default 50%).
- However, Cluster Autoscaler will NOT scale down a node if:
  1. The node has the annotation \`cluster-autoscaler.kubernetes.io/scale-down-disabled: "true"\`.
  2. The node group would drop below \`cluster-api-autoscaler-node-group-min-size\`.
  3. Pods without a controller, pods with local storage, or pods with restrictive PodDisruptionBudgets (PDBs) reside on the node.`,
  },
  {
    id: 'nkp-q8',
    badge: 'Multi-Cluster Workspaces & Governance',
    title: 'Primary Benefit of Attaching Clusters to a Workspace',
    scenario:
      'An administrator has successfully deployed multiple Kubernetes clusters and wants to manage them through a centralized workspace in Kommander.',
    prompt: 'What is the primary benefit of attaching clusters to a workspace?',
    options: [
      {
        id: 'a',
        text: 'Organizing and managing clusters through a common administrative and operational context.',
        isCorrect: true,
        explanation: 'Correct! Workspaces in Kommander provide multi-tenant isolation, allowing administrators to group clusters logically and apply federated RBAC, platform application deployments, and operational policies uniformly.',
        nutanixEquivalent: 'Kommander Workspace Federation & Governance',
      },
      {
        id: 'b',
        text: 'Automatically migrating application workloads between clusters without administrator input.',
        isCorrect: false,
        explanation: 'Workspaces do not perform autonomous cross-cluster pod migration.',
        nutanixEquivalent: 'Workload Migration',
      },
      {
        id: 'c',
        text: 'Replacing cluster networking with a single network configuration across all clusters.',
        isCorrect: false,
        explanation: 'Each cluster retains its own independent CNI network and IP addressing.',
        nutanixEquivalent: 'Independent CNI Networking',
      },
      {
        id: 'd',
        text: 'Converting multiple clusters into a single Kubernetes control plane for workload scheduling.',
        isCorrect: false,
        explanation: 'Workspaces do not merge clusters into a single giant control plane; each cluster maintains its own sovereign control plane.',
        nutanixEquivalent: 'Sovereign Control Planes',
      },
    ],
    correctOptionId: 'a',
    keyTakeaway: 'Workspaces establish a common administrative, governance, and operational boundary for grouping clusters, federating RBAC, and dispatching platform applications.',
    deepExplanation: `Kommander Workspace Architecture:
- A Workspace is a logical grouping of one or more managed or attached Kubernetes clusters.
- Enables centralized GitOps platform application deployments (e.g. Istio, Prometheus, Grafana).
- Enforces consistent WorkspaceRoleBindings across all member clusters from a single configuration point.`,
  },
  {
    id: 'nkp-q9',
    badge: 'Platform Applications & GitOps Architecture',
    title: 'Foundational Applications Required for Platform Applications',
    scenario:
      'For an administrator to enable any application, which foundational applications must be enabled for Platform Applications to work properly?',
    prompt: 'Which foundational applications must be enabled for Platform Applications to work properly?',
    options: [
      {
        id: 'a',
        text: 'Flux, Reloader, Traefik',
        isCorrect: true,
        explanation: 'Correct! Flux provides the underlying GitOps engine to reconcile Helm releases; Reloader watches ConfigMaps and Secrets to trigger rolling pod updates upon configuration changes; and Traefik serves as the ingress controller routing web traffic.',
        nutanixEquivalent: 'NKP Core Foundation: Flux, Reloader, Traefik',
      },
      {
        id: 'b',
        text: 'Reloader, Dex, Harbor',
        isCorrect: false,
        explanation: 'Harbor is an optional container registry, not a foundational prerequisite for platform apps.',
        nutanixEquivalent: 'Harbor Registry Platform App',
      },
      {
        id: 'c',
        text: 'Helm, Reloader, External DNS',
        isCorrect: false,
        explanation: 'External DNS is an optional add-on; Flux (not Helm standalone) is the declarative GitOps operator.',
        nutanixEquivalent: 'External DNS Add-on',
      },
      {
        id: 'd',
        text: 'Gatekeeper, Helm, Flux',
        isCorrect: false,
        explanation: 'Gatekeeper is policy enforcement, not the foundational networking and configuration stack.',
        nutanixEquivalent: 'OPA Gatekeeper Policy Engine',
      },
    ],
    correctOptionId: 'a',
    keyTakeaway: 'Flux (GitOps reconciliation), Reloader (automatic configuration reloading), and Traefik (ingress routing) form the essential foundation for NKP Platform Applications.',
    deepExplanation: `Foundational Platform Architecture:
1. **Flux (Helm Controller & Source Controller)**: Declaratively pulls Helm charts from Git or OCI repositories and installs/updates AppDeployments.
2. **Reloader**: Detects changes in ConfigMaps and Secrets and performs rolling upgrades on Deployments/StatefulSets automatically.
3. **Traefik**: Ingress controller providing TLS termination and reverse proxying for UI applications like Kommander, Grafana, and Dex.`,
  },
  {
    id: 'nkp-q10',
    badge: 'Multi-Cluster Connectivity & Networking',
    title: 'Resolving Cluster Attachment Failure Due to Restricted API Access',
    scenario:
      'A cluster attachment has failed due to the cluster\'s API not being accessible from the same network as the Management Cluster.',
    prompt: 'Which action must be taken to allow a successful attachment of the cluster?',
    options: [
      {
        id: 'a',
        text: 'Select No additional networking restrictions.',
        isCorrect: false,
        explanation: 'Selecting no restrictions assumes direct routable connectivity, which will continue to fail.',
        nutanixEquivalent: 'Direct Routable Mode',
      },
      {
        id: 'b',
        text: 'Create a secure tunnel using NKP and kubetunnel.',
        isCorrect: true,
        explanation: 'Correct! When an attached cluster is behind NAT, private firewalls, or on an isolated network where the management cluster cannot directly dial its API server, NKP uses kubetunnel to establish an encrypted outbound tunnel over HTTPS (TCP/443).',
        nutanixEquivalent: 'NKP Secure Tunnel (kubetunnel)',
      },
      {
        id: 'c',
        text: 'Create a service account.',
        isCorrect: false,
        explanation: 'A service account provides authentication tokens but does not solve IP routing and network reachability.',
        nutanixEquivalent: 'Kubernetes Service Account',
      },
      {
        id: 'd',
        text: 'Update the kubeconfig file to have an external IP address.',
        isCorrect: false,
        explanation: 'If corporate security prevents exposing the API server externally, updating the kubeconfig with an external IP is either impossible or violates policy.',
        nutanixEquivalent: 'Public IP Exposure',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'NKP Secure Tunnel (kubetunnel) enables Kommander to manage attached clusters located behind NAT or firewalls without requiring inbound firewall openings.',
    deepExplanation: `Kubetunnel in NKP:
- The attached cluster initiates an outbound HTTPS connection to the Kommander management cluster.
- A secure bidirectional proxy tunnel is established.
- Kommander routes API calls, metric queries, and GitOps synchronization payloads through this tunnel, bypassing on-premise firewall restrictions.`,
  },
  {
    id: 'nkp-q11',
    badge: 'Air-Gapped Installation & Prerequisites',
    title: 'Host Prerequisite for Running NKP Konvoy CLI in Air-Gapped Setup',
    scenario:
      'An administrator is preparing the host that will run the NKP Konvoy CLI to bootstrap an air-gapped cluster.',
    prompt: 'Which component must be present on that host before starting?',
    options: [
      {
        id: 'a',
        text: 'A CNI plugin such as Cilium',
        isCorrect: false,
        explanation: 'CNI plugins are deployed inside the Kubernetes nodes during cluster creation, not required beforehand on the administrative host.',
        nutanixEquivalent: 'Cilium / Calico CNI',
      },
      {
        id: 'b',
        text: 'A container engine such as Docker',
        isCorrect: true,
        explanation: 'Correct! A container engine such as Docker (or containerd) is a mandatory prerequisite on the bastion/operator host because the NKP CLI spins up a temporary Kind (Kubernetes-in-Docker) bootstrap cluster to run Cluster API.',
        nutanixEquivalent: 'Docker Container Engine on Bastion',
      },
      {
        id: 'c',
        text: 'An etcd cluster for storing state',
        isCorrect: false,
        explanation: 'Etcd is provisioned automatically inside the control plane nodes by kubeadm/CAPI.',
        nutanixEquivalent: 'Etcd Cluster Datastore',
      },
      {
        id: 'd',
        text: 'The Cluster API (CAPI) controller manager',
        isCorrect: false,
        explanation: 'CAPI controller managers are launched by the CLI inside the bootstrap cluster, not manually installed on the host OS.',
        nutanixEquivalent: 'CAPI Controller Manager Pods',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'Docker is a mandatory prerequisite on the bastion host because NKP relies on Kind (Kubernetes-in-Docker) to run the initial bootstrap cluster.',
    deepExplanation: `Bootstrap Cluster Prerequisites:
- The NKP CLI orchestrates infrastructure creation declaratively via Cluster API (CAPI).
- To run CAPI before the target cluster exists, NKP launches a single-node Kind cluster locally on the bastion machine.
- Kind requires an active Docker daemon (\`systemctl start docker\`) on the bastion host.`,
  },
  {
    id: 'nkp-q12',
    badge: 'Node Architecture & Sizing',
    title: 'Minimum Worker System Disk Sizing Requirement in NKP',
    scenario:
      'An administrator is sizing the system disk of each worker machine in an NKP cluster, which holds /var/lib/kubelet and /var/lib/containerd.',
    prompt: 'What is the minimum approximate size NKP requires for this action?',
    options: [
      {
        id: 'a',
        text: '32 GiB',
        isCorrect: false,
        explanation: '32 GiB is insufficient and will quickly cause DiskPressure node conditions and pod evictions.',
        nutanixEquivalent: 'Undersized Disk Capacity',
      },
      {
        id: 'b',
        text: '80 GiB',
        isCorrect: true,
        explanation: 'Correct! Nutanix Kubernetes Platform documentation specifies a minimum recommendation of approximately 80 GiB for the root/system disk of worker nodes to support the OS, containerd image cache, kubelet working files, and ephemeral container storage.',
        nutanixEquivalent: '80 GiB Minimum Worker System Disk',
      },
      {
        id: 'c',
        text: '120 GiB',
        isCorrect: false,
        explanation: '120 GiB is a generous production sizing, but 80 GiB is the official documented minimum prerequisite.',
        nutanixEquivalent: 'Production Expanded Disk',
      },
      {
        id: 'd',
        text: '150 GiB',
        isCorrect: false,
        explanation: '150 GiB exceeds the baseline minimum requirement for standard worker nodes.',
        nutanixEquivalent: 'Large Capacity Tier',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'NKP requires a minimum system disk size of 80 GiB for worker nodes to accommodate the OS, container runtime images, and kubelet runtime directories.',
    deepExplanation: `Worker Node Disk Sizing Details:
- \`/var/lib/containerd\`: Holds unpacked container image layers and container overlays.
- \`/var/lib/kubelet\`: Stores emptyDir volumes, pod logs, and plugin sockets.
- If system disk space falls below 15% free, kubelet enters \`DiskPressure\` eviction mode. 80 GiB ensures reliable operation during image pulls and updates.`,
  },
  {
    id: 'nkp-q13',
    badge: 'Autoscaling & Node Pool Management',
    title: 'Configuration Level for Cluster Autoscaler in NKP',
    scenario:
      'An administrator wants to configure Cluster Autoscaler for an NKP cluster. The NKP cluster has multiple Worker Node Pools associated with it.',
    prompt: 'On what level should the administrator configure the Cluster Autoscaler?',
    options: [
      {
        id: 'a',
        text: 'Worker Node Pool',
        isCorrect: true,
        explanation: 'Correct! In NKP and Cluster API architecture, Cluster Autoscaler is configured at the Worker Node Pool (MachineDeployment) level by setting the min-size and max-size annotations.',
        nutanixEquivalent: 'Worker Node Pool / MachineDeployment Level',
      },
      {
        id: 'b',
        text: 'Kubernetes Cluster',
        isCorrect: false,
        explanation: 'The cluster resource defines the global control plane and networking, while autoscaling bounds apply specifically per worker node pool.',
        nutanixEquivalent: 'Global Cluster Resource',
      },
      {
        id: 'c',
        text: 'Worker Pod',
        isCorrect: false,
        explanation: 'Pods are scaled by Horizontal Pod Autoscaler (HPA), not Cluster Autoscaler.',
        nutanixEquivalent: 'Horizontal Pod Autoscaler (HPA)',
      },
      {
        id: 'd',
        text: 'Worker Node',
        isCorrect: false,
        explanation: 'Individual nodes are ephemeral and created/destroyed dynamically; scaling policies cannot be anchored to a single node instance.',
        nutanixEquivalent: 'Individual Node Instance',
      },
    ],
    correctOptionId: 'a',
    keyTakeaway: 'Cluster Autoscaler operates on Worker Node Pools (MachineDeployments), allowing independent min and max node boundaries per pool.',
    deepExplanation: `Autoscaling Hierarchy in NKP:
- Each Worker Node Pool corresponds to a Cluster API \`MachineDeployment\`.
- Autoscaling annotations are applied to the pool:
  - \`cluster.x-k8s.io/cluster-api-autoscaler-node-group-min-size\`
  - \`cluster.x-k8s.io/cluster-api-autoscaler-node-group-max-size\`
- This enables heterogeneous pools (e.g. GPU pools, high-memory pools) to scale independently based on workload demand.`,
  },
  {
    id: 'nkp-q14',
    badge: 'Licensing & Editions',
    title: 'Inclusions in NKP Full Stack Ultimate License',
    scenario: 'A customer is evaluating the enterprise software bundle included with the NKP Full Stack Ultimate license.',
    prompt: 'What is included in NKP Full Stack Ultimate license?',
    options: [
      {
        id: 'a',
        text: 'NCI Starter',
        isCorrect: false,
        explanation: 'NCI Starter is the entry-level infrastructure tier without advanced software-defined storage and multi-cluster orchestration.',
        nutanixEquivalent: 'NCI Starter Tier',
      },
      {
        id: 'b',
        text: 'NCI Pro',
        isCorrect: false,
        explanation: 'NCI Pro includes rich enterprise features but does not include the top-tier software bundle found in Ultimate.',
        nutanixEquivalent: 'NCI Pro Tier',
      },
      {
        id: 'c',
        text: 'NCI Ultimate',
        isCorrect: true,
        explanation: 'Correct! The NKP Full Stack Ultimate license combines the complete Nutanix Cloud Infrastructure (NCI Ultimate) hyperconverged stack with NKP Ultimate management and governance.',
        nutanixEquivalent: 'NCI Ultimate Software Tier',
      },
      {
        id: 'd',
        text: 'NCI-C Ultimate',
        isCorrect: false,
        explanation: 'NCI-C is specific to cloud bare-metal offerings rather than the flagship full-stack on-premises SKU.',
        nutanixEquivalent: 'NCI-C Cloud Bare-Metal Tier',
      },
    ],
    correctOptionId: 'c',
    keyTakeaway: 'NKP Full Stack Ultimate bundles the top-tier Nutanix Cloud Infrastructure (NCI Ultimate) hyperconverged platform.',
    deepExplanation: `Licensing Tiers Overview:
- **NKP Starter**: Essential single-cluster Kubernetes engine (Konvoy).
- **NKP Pro**: Multi-cluster management, Workspaces, and centralized governance (Kommander).
- **NKP Ultimate**: Complete enterprise suite including multi-cloud federation, AI/GPU orchestration, and advanced security.
- **NKP Full Stack Ultimate**: Bundles NCI Ultimate with NKP Ultimate for comprehensive hyperconverged hardware-to-app lifecycle management.`,
  },
  {
    id: 'nkp-q15',
    badge: 'GitOps & Application Operations',
    title: 'Validating Helm Release Status in NKP',
    scenario:
      'A technology company has decided to migrate its infrastructure to NKP to improve the scalability and management of its applications. After a successful initial implementation, the operations team faces a new challenge of validating the Helm Releases to ensure that all applications are running correctly and avoid problems in production.',
    prompt: 'Which command should the company execute to know the right status of their Helm Releases?',
    options: [
      {
        id: 'a',
        text: 'kubectl get namespaces',
        isCorrect: false,
        explanation: 'Lists namespaces, revealing nothing about Helm release deployment states.',
        nutanixEquivalent: 'Namespace Inspection',
      },
      {
        id: 'b',
        text: 'kubectl apply -f fluent-bit-overrides.yaml',
        isCorrect: false,
        explanation: 'Applies configuration overrides rather than checking status.',
        nutanixEquivalent: 'Manifest Application',
      },
      {
        id: 'c',
        text: 'kubectl get helmreleases -n ${PROJECT_NAMESPACE}',
        isCorrect: true,
        explanation: 'Correct! NKP uses Flux HelmRelease custom resources to manage applications. Querying kubectl get helmreleases in the project/workspace namespace displays readiness conditions, release status, and reconciliation status.',
        nutanixEquivalent: 'Flux HelmRelease Custom Resource Status',
      },
      {
        id: 'd',
        text: 'kubectl edit helmreleases -n ${PROJECT_NAMESPACE}',
        isCorrect: false,
        explanation: 'Opens an interactive text editor to modify the spec, which does not provide a concise operational status overview.',
        nutanixEquivalent: 'Interactive Resource Editor',
      },
    ],
    correctOptionId: 'c',
    keyTakeaway: 'Use kubectl get helmreleases -n <namespace> to inspect the health, reconciliation state, and readiness of Flux-managed applications in NKP.',
    deepExplanation: `HelmRelease Troubleshooting in NKP:
- In NKP GitOps, applications are defined as Flux \`HelmRelease\` CRDs.
- Running \`kubectl get hr -n <namespace>\` displays:
  - \`READY\`: True/False
  - \`STATUS\`: Release reconciliation succeeded / install failed
  - \`AGE\`: Time since last reconciliation
- Detailed failure reasons can be viewed with \`kubectl describe hr <name> -n <namespace>\`.`,
  },
  {
    id: 'nkp-q16',
    badge: 'Logging & Storage Architecture',
    title: 'Safely Enabling Fluent Bit on an NKP Management Cluster',
    scenario: 'What should an administrator do to safely enable Fluentbit on an NKP management cluster?',
    prompt: 'What should an administrator do to safely enable Fluentbit on an NKP management cluster?',
    options: [
      {
        id: 'a',
        text: 'Configure additional storage on the rook-ceph-cluster.',
        isCorrect: true,
        explanation: 'Correct! On NKP management clusters, centralized logging aggregation and buffering through Fluent Bit and the logging stack require underlying persistent block/shared storage managed by the rook-ceph-cluster.',
        nutanixEquivalent: 'Rook-Ceph Cluster Storage Expansion',
      },
      {
        id: 'b',
        text: 'Configure additional storage on the rook-grafana-cluster.',
        isCorrect: false,
        explanation: 'There is no rook-grafana-cluster; Grafana is a dashboard application, not a storage cluster provider.',
        nutanixEquivalent: 'Invalid Storage Construct',
      },
      {
        id: 'c',
        text: 'Create an NFS share and mount to all pods in the cluster.',
        isCorrect: false,
        explanation: 'Manual host-level NFS mounts are deprecated in favor of dynamic Kubernetes storage classes.',
        nutanixEquivalent: 'Manual NFS Mounting',
      },
      {
        id: 'd',
        text: 'Create an S3 object share, then update the default storage service.',
        isCorrect: false,
        explanation: 'Fluent Bit buffering on node filesystems and log collectors relies on local/block PVCs, not object storage for active buffering.',
        nutanixEquivalent: 'Object Store Buffer',
      },
    ],
    correctOptionId: 'a',
    keyTakeaway: 'Enabling centralized logging components like Fluent Bit buffers on the management cluster requires provisioning adequate storage in the rook-ceph cluster.',
    deepExplanation: `Management Cluster Storage for Logging:
- Fluent Bit forwards logs to Loki or centralized Elasticsearch/Opensearch instances.
- The logging pipeline requires buffer storage to prevent data loss during network congestion.
- In NKP management clusters, Rook-Ceph provides the scalable CephBlockPool and CephFilesystem underpinning these logging PVCs.`,
  },
  {
    id: 'nkp-q17',
    badge: 'Image Builder & OS Support Matrix',
    title: 'Ubuntu 24.04 Base Image Support in NKP',
    scenario:
      'An NKP administrator is using Nutanix Image Builder (NIB) and wants to utilize an Ubuntu 24.04 base image for a new NKP machine image on Nutanix. The environment is currently at NKP version 2.15.',
    prompt: 'What is the best supported course of action?',
    options: [
      {
        id: 'a',
        text: 'Upgrade NKP to 2.16 and use NIB to create the new Ubuntu machine image.',
        isCorrect: false,
        explanation: 'NKP 2.16 did not introduce or qualify Ubuntu 24.04 LTS.',
        nutanixEquivalent: 'NKP 2.16 Support Matrix',
      },
      {
        id: 'b',
        text: 'Use NIB to create the new Ubuntu machine image and manually add to Prism Central.',
        isCorrect: false,
        explanation: 'NIB templates in NKP 2.15 lack the necessary cloud-init, kernel module, and containerd configuration for Ubuntu 24.04.',
        nutanixEquivalent: 'Unsupported OS Template Version',
      },
      {
        id: 'c',
        text: 'Use NIB to create the new Ubuntu machine image and manually add to Prism Element.',
        isCorrect: false,
        explanation: 'Manual addition does not resolve the underlying OS compatibility scripts inside NIB.',
        nutanixEquivalent: 'Manual Prism Element Upload',
      },
      {
        id: 'd',
        text: 'Upgrade NKP to 2.17 and use NIB to create the new Ubuntu machine image.',
        isCorrect: true,
        explanation: 'Correct! Official qualification and Nutanix Image Builder (NIB) support for Ubuntu 24.04 LTS was formally introduced in NKP version 2.17.',
        nutanixEquivalent: 'NKP 2.17 Release Qualification for Ubuntu 24.04 LTS',
      },
    ],
    correctOptionId: 'd',
    keyTakeaway: 'Upgrade to NKP 2.17 or higher to gain official Nutanix Image Builder (NIB) support for Ubuntu 24.04 LTS machine images.',
    deepExplanation: `OS Lifecycle & Nutanix Image Builder (NIB):
- NIB bundles specific Ansible playbooks for each supported OS release.
- Ubuntu 24.04 LTS introduced significant system changes (systemd, netplan, apparmor).
- NKP 2.17 added official Ansible roles and validation tests verifying containerd, CNI, and CSI drivers against Ubuntu 24.04.`,
  },
  {
    id: 'nkp-q18',
    badge: 'Workspaces & Application Governance',
    title: 'Centralized Platform Application Deployment in Workspaces',
    scenario:
      'An administrator has attached a Kubernetes cluster to an NKP workspace that contains other clusters.',
    prompt: 'What is a benefit of attaching this new cluster to that workspace?',
    options: [
      {
        id: 'a',
        text: 'Combines all nodes into one cluster',
        isCorrect: false,
        explanation: 'Workspaces group clusters logically; they do not merge nodes or physical clusters.',
        nutanixEquivalent: 'Physical Node Merging',
      },
      {
        id: 'b',
        text: 'Allows Centralized Platform application deployment',
        isCorrect: true,
        explanation: 'Correct! Any platform application (monitoring, logging, security, ingress) enabled at the workspace level is automatically deployed and synchronized across all member clusters.',
        nutanixEquivalent: 'Workspace Centralized Application Deployment (AppDeployment)',
      },
      {
        id: 'c',
        text: 'Spans workloads across workspaces',
        isCorrect: false,
        explanation: 'Workspaces are strict isolation boundaries; workloads do not span across different workspaces.',
        nutanixEquivalent: 'Cross-Workspace Spanning',
      },
      {
        id: 'd',
        text: 'Eliminates the need to authenticate to the cluster',
        isCorrect: false,
        explanation: 'Authentication is always required; Kommander federates and enforces authentication rather than eliminating it.',
        nutanixEquivalent: 'Federated Identity Enforcement',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'Attaching a cluster to a workspace enables centralized platform application dispatch, instantly synchronizing standard monitoring, logging, and security stacks to the cluster.',
    deepExplanation: `Fleet Management via AppDeployment:
- In Kommander, an administrator enables an application (such as \`kube-prometheus-stack\` or \`gatekeeper\`) once on a Workspace.
- When any cluster joins the workspace, the GitOps controller immediately provisions that application onto the new cluster with workspace-wide configurations.`,
  },
  {
    id: 'nkp-q19',
    badge: 'Cluster Lifecycle Management',
    title: 'Deleting a Self-Managed NKP Cluster',
    scenario: 'A platform engineer needs to delete a self-managed cluster.',
    prompt: 'What should the engineer do prior to completing this task?',
    options: [
      {
        id: 'a',
        text: 'Delete the bootstrap cluster.',
        isCorrect: false,
        explanation: 'The bootstrap cluster was already deleted after initial deployment; it does not exist at this point.',
        nutanixEquivalent: 'Non-existent Bootstrap Cluster',
      },
      {
        id: 'b',
        text: 'Delete the workload cluster.',
        isCorrect: false,
        explanation: 'Deleting workload clusters does not prepare the self-managed cluster for its own decommissioning.',
        nutanixEquivalent: 'Workload Cluster Deletion',
      },
      {
        id: 'c',
        text: 'Create a Bootstrap cluster.',
        isCorrect: true,
        explanation: 'Correct! Because a self-managed cluster hosts its own Cluster API (CAPI) controllers, you must create a temporary bootstrap cluster on the bastion host and move the CAPI resources to it so an external controller can orchestrate the teardown of the self-managed VMs.',
        nutanixEquivalent: 'Bootstrap Cluster Creation & CAPI Pivot',
      },
      {
        id: 'd',
        text: 'Move the CAPI resources.',
        isCorrect: false,
        explanation: 'You cannot move CAPI resources until a destination bootstrap cluster has been created first.',
        nutanixEquivalent: 'Premature CAPI Resource Move',
      },
    ],
    correctOptionId: 'c',
    keyTakeaway: 'Before deleting a self-managed cluster, you must first create a temporary bootstrap cluster to take ownership of CAPI management resources during deletion.',
    deepExplanation: `Deleting Self-Managed Clusters:
1. \`nkp create bootstrap\`: Creates a Kind cluster on the bastion host.
2. \`nkp move capi-resources --to-kubeconfig <bootstrap-kubeconfig>\`: Moves CAPI custom resources from the self-managed cluster into the bootstrap cluster.
3. \`nkp delete cluster --cluster-name <name> --kubeconfig <bootstrap-kubeconfig>\`: Teardown proceeds from the outside.
4. \`nkp delete bootstrap\`: Destroys the temporary Kind container.`,
  },
  {
    id: 'nkp-q20',
    badge: 'Sizing & Prerequisites',
    title: 'Prerequisite for Upgrading NKP License to Ultimate',
    scenario: 'What is a prerequisite for upgrading an NKP license to Ultimate?',
    prompt: 'What is a prerequisite for upgrading an NKP license to Ultimate?',
    options: [
      {
        id: 'a',
        text: 'Size the ETCD nodes appropriately to support the installation of default platform services.',
        isCorrect: false,
        explanation: 'Etcd handles cluster state metadata, but platform applications execute and consume resources on worker nodes.',
        nutanixEquivalent: 'Etcd Node Sizing',
      },
      {
        id: 'b',
        text: 'Size the Worker nodes appropriately to support the installation of default platform services.',
        isCorrect: true,
        explanation: 'Correct! Upgrading to NKP Ultimate deploys a comprehensive suite of platform services (advanced observability, multi-cluster federated Thanos, centralized logging, Insights, and security scanners), which run as pods on the worker nodes. Worker nodes must have adequate CPU and memory.',
        nutanixEquivalent: 'Worker Node Capacity Sizing for Ultimate Services',
      },
      {
        id: 'c',
        text: 'Size the Sidecar containers appropriately to support the installation of default platform services.',
        isCorrect: false,
        explanation: 'Sidecar resource requests are packaged by the vendor charts and cannot be sized globally in advance.',
        nutanixEquivalent: 'Sidecar Container Specs',
      },
      {
        id: 'd',
        text: 'Size the Control Plane nodes appropriately to support the installation of default platform services.',
        isCorrect: false,
        explanation: 'Control plane nodes run Kubernetes API, scheduler, and controller-manager, not platform user-space services.',
        nutanixEquivalent: 'Control Plane Node Sizing',
      },
    ],
    correctOptionId: 'b',
    keyTakeaway: 'Worker nodes must be appropriately sized with sufficient CPU and RAM before upgrading to NKP Ultimate to host the full suite of default platform services.',
    deepExplanation: `Ultimate Platform Services Footprint:
- NKP Ultimate enables advanced applications across the cluster:
  - Centralized Thanos Querier & Store Gateway
  - Fluent Bit and Loki logging pipelines
  - NKP Insights anomaly detection engine
  - OPA Gatekeeper policy engines
- Because all these workloads run on worker nodes, under-sizing worker nodes will lead to Pending pods and memory throttling.`,
  },
];
